import logging
import sys
from types import TracebackType
from typing import Never

from ._app import GuiCapabilityLiteral
from ._overseer import OVERSEER

logger = logging.getLogger(__name__)

class _AppFrame(type):
    def __enter__(
        self,
        app_name: str,
        gui_capability: GuiCapabilityLiteral,
        app_version: str,
        /,
        display_name: str | None = None,
        owner_name: str | None = None,
        website_domain: str | None = None,
    ) -> None:
        OVERSEER.initialize_application(
            app_name=app_name,
            display_name=display_name,
            gui_capability=gui_capability,
            owner_name=owner_name,
            version=app_version,
            web_domain=website_domain,
        )

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None
    ):
        OVERSEER.shutdown()
        if exc_type is None:
            return
    
    def replace_excepthook(self) -> None:
        original_excepthook = sys.excepthook

        def logging_excepthook(
            exc_type: type[BaseException],
            exc_value: BaseException,
            exc_traceback: TracebackType | None,
        ) -> None:
            
            logger.exception(
                "Uncaught exception",
                exc_info=(exc_type, exc_value, exc_traceback),
            )
            original_excepthook(exc_type, exc_value, exc_traceback)
        
        sys.excepthook = logging_excepthook


class QtQpRoot(metaclass=_AppFrame):
    def __new__(cls) -> Never:
        raise NotImplementedError

    def __init__(self) -> Never:
        raise NotImplementedError

    @staticmethod
    def run_application() -> None:
        OVERSEER.run_app()