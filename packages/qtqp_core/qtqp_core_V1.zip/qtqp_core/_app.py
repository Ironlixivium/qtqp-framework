from enum import Enum
from typing import Final, Literal

from PySide6.QtCore import QCoreApplication, QObject

type GuiCapabilityLiteral = Literal["non-gui", "windowing", "widgets"]


class _GuiCapability(Enum):
    _value_: GuiCapabilityLiteral
    NON_GUI = "non-gui"
    WINDOWING = "windowing"
    WIDGETS = "widgets"

class QtQpApplicationController(QObject):
    def __init__(
        self,
        *,
        gui_capability: GuiCapabilityLiteral,
        display_name: str | None,
        name: str,
        owner_name: str | None,
        parent: QObject,
        version: str,
        website_domain: str | None,
    ) -> None:
        super().__init__(parent)
        self._capability: Final[_GuiCapability] = _GuiCapability(gui_capability)
        self._app_obj: QCoreApplication
        self.display_name: str | None = display_name
        self.name: str = name
        self.owner_name: str | None = owner_name
        self.version: str = version
        self.website_domain: str | None = website_domain

    @property
    def app_object(self) -> QCoreApplication:
        return self._app_obj

    @property
    def gui_capability(self) -> _GuiCapability:
        return self._capability

    def run(self) -> None:
        self._app_obj.exec()

    def shutdown_request(self) -> None:
        self._app_obj.quit()
    
    def shutdown_force(self) -> None:
        self._app_obj.exit()

    def _instantiate_application(self, *, capability: _GuiCapability) -> None:
        bad = QCoreApplication.instance()
        if bad is not None:
            raise Exception("Do not instantiate any version of QCoreApplication.")

        if capability == _GuiCapability.NON_GUI:
            app = QCoreApplication()
        else:
            if capability == _GuiCapability.WINDOWING:
                from PySide6.QtGui import QGuiApplication

                app = QGuiApplication()

            else:
                from PySide6.QtWidgets import QApplication

                app = QApplication()

                # QApplication config
                # none so far!

            # QGuiApplication and above config

            app.setQuitOnLastWindowClosed(False)
            if self.display_name is not None:
                app.setApplicationDisplayName(self.display_name)

        # QCoreApplication and above config (All Qt applications)

        app.setApplicationName(self.name)
        app.setApplicationVersion(self.version)
        if self.owner_name is not None:
            app.setOrganizationName(self.owner_name)
        if self.website_domain is not None:
            app.setOrganizationDomain(self.website_domain)
        app.setQuitLockEnabled(False)

        self._app_obj = app
