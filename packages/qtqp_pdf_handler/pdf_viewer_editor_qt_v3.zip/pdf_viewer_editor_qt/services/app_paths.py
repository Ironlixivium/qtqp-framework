from __future__ import annotations

import sys
from pathlib import Path


def package_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "PDF Extension"
    return Path(__file__).resolve().parents[2]


def templates_dir() -> Path:
    return package_dir() / "resources" / "pdfs"
