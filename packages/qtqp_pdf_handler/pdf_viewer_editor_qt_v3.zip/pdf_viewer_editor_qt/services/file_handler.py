import sys
from collections import OrderedDict
from pathlib import Path
from typing import Literal

from PySide6.QtCore import QFile, QIODevice

type _CacheEntry = tuple[Literal["qrc"], bytes] | tuple[Literal["disk"], int, int, bytes]


class PdfBytesLoader:
    """
    Reads PDFs from:
      - disk (next to the exe/script, and also CWD as fallback)
      - Qt resources (":/pdfs/whatever.pdf") via QFile

    Writes PDFs to:
      - a caller-provided output directory (or absolute path), defaulting to next to the exe/script.
    """

    def __init__(self) -> None:
        self._init_runtime()  # runs on instantiation
        self._bytes_cache: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._bytes_cache_max_items: int = 64

    def _init_runtime(self) -> None:
        self.frozen: bool = bool(getattr(sys, "frozen", False))
        self.cwd: Path = Path.cwd().resolve()
        self.app_dir: Path = Path(sys.executable).resolve().parent if self.frozen else Path(__file__).resolve().parent

        # Prefer "next to app", but allow CWD fallback for reading
        self._read_dirs: tuple[Path, ...] = (self.app_dir, self.cwd)

    # -------- public API --------

    def list_pdfs(self, *, recursive: bool = False, base_dir: Path | None = None) -> list[Path]:
        """
        Lists *disk* PDFs in base_dir (default: next to app).
        (Qt resources are not listed here.)
        """
        base = (base_dir or self.app_dir).resolve()
        it = base.rglob("*.pdf") if recursive else base.glob("*.pdf")
        return sorted((p.resolve() for p in it if p.is_file()), key=lambda p: p.as_posix().lower())

    def read_bytes(self, name_or_path: str | Path) -> bytes:
        """
        Accepts either:
          - disk path (absolute or relative)
          - Qt resource path like ':/pdfs/Foo.pdf'
        """
        qrc = self._as_qrc_path(name_or_path)
        if qrc is not None:
            cache_key = qrc
            cached = self._bytes_cache.get(cache_key)
            if cached is not None and cached[0] == "qrc":
                self._bytes_cache.move_to_end(cache_key)
                return cached[1]
            data = self._read_qrc_bytes(qrc)
            self._bytes_cache[cache_key] = ("qrc", data)
            self._evict_bytes_cache_if_needed()
            return data

        path = self._resolve_disk_pdf(name_or_path)
        cache_key = str(path)
        stat = path.stat()
        cached = self._bytes_cache.get(cache_key)
        if cached is not None and cached[0] == "disk":
            cached_mtime_ns, cached_size, cached_bytes = cached[1], cached[2], cached[3]
            if cached_mtime_ns == stat.st_mtime_ns and cached_size == stat.st_size:
                self._bytes_cache.move_to_end(cache_key)
                return cached_bytes
        data = path.read_bytes()
        self._bytes_cache[cache_key] = ("disk", stat.st_mtime_ns, stat.st_size, data)
        self._evict_bytes_cache_if_needed()
        return data

    def write_bytes(
        self,
        name_or_path: str | Path,
        data: bytes,
        *,
        overwrite: bool = False,
        out_dir: str | Path | None = None,
    ) -> Path:
        """
        Writes to disk only.
          - If name_or_path is absolute: write there.
          - If relative: write under out_dir (default: next to app).
        """
        if self._as_qrc_path(name_or_path) is not None:
            raise ValueError("Cannot write to Qt resource paths (':/...'). Choose a disk path instead.")

        out_path = self._resolve_write_path(name_or_path, out_dir=out_dir)

        if out_path.exists() and not overwrite:
            raise FileExistsError(f"{out_path} already exists (set overwrite=True)")

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(data)
        return out_path

    # -------- internals --------

    def _as_qrc_path(self, name_or_path: str | Path) -> str | None:
        if isinstance(name_or_path, Path):
            return None
        s = name_or_path.strip()
        if s.startswith(":/"):
            return s
        # accept qrc:/... too
        if s.startswith("qrc:/"):
            return ":" + s[3:]
        return None

    def _read_qrc_bytes(self, qrc_path: str) -> bytes:
        f = QFile(qrc_path)
        if not f.open(QIODevice.OpenModeFlag.ReadOnly):
            raise FileNotFoundError(f"Resource not found or not readable: {qrc_path}")
        try:
            return bytes(f.readAll())
        finally:
            f.close()

    def _evict_bytes_cache_if_needed(self) -> None:
        while len(self._bytes_cache) > self._bytes_cache_max_items:
            self._bytes_cache.popitem(last=False)

    def _ensure_pdf_suffix(self, p: Path) -> Path:
        return p if p.suffix.lower() == ".pdf" else p.with_suffix(".pdf")

    def _resolve_disk_pdf(self, name_or_path: str | Path) -> Path:
        p = Path(name_or_path)
        if p.is_absolute():
            p = self._ensure_pdf_suffix(p)
            if not p.exists():
                raise FileNotFoundError(str(p))
            return p.resolve()

        # Relative: try next-to-app first, then CWD.
        p = self._ensure_pdf_suffix(p)

        tried: list[Path] = []
        for base in self._read_dirs:
            candidate = (base / p).resolve()
            tried.append(candidate)
            if candidate.exists():
                return candidate

        tried_s = "\n".join(f"  - {t}" for t in tried)
        raise FileNotFoundError(f"PDF not found. Tried:\n{tried_s}")

    def _resolve_write_path(self, name_or_path: str | Path, *, out_dir: str | Path | None) -> Path:
        p = Path(name_or_path)
        p = self._ensure_pdf_suffix(p)

        if p.is_absolute():
            return p.resolve()

        base = Path(out_dir).resolve() if out_dir is not None else self.app_dir
        return (base / p).resolve()


if __name__ == "__main__":
    h = PdfBytesLoader()
    print("frozen:", h.frozen)
    print("cwd:", h.cwd)
    print("app_dir:", h.app_dir)
