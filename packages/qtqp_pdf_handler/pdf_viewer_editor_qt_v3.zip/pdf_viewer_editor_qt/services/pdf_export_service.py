from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import fitz

from ..editor.annotation_model import (
    AnnotationRecord,
    RectAnnotation,
    StampAnnotation,
    TextBoxAnnotation,
)
from ..editor.geometry import PtRect


def export_pdf(
    *,
    source_pdf_bytes: bytes,
    annotations: list[AnnotationRecord],
    resolve_stamp_path: Callable[[str], Path | None],
    output_path: str | Path,
) -> Path:
    doc = fitz.open(stream=source_pdf_bytes, filetype="pdf")
    try:
        annotations_by_page: dict[int, list[AnnotationRecord]] = {}
        for ann in annotations:
            annotations_by_page.setdefault(ann.page_index, []).append(ann)

        for page_index in range(doc.page_count):
            page = doc.load_page(page_index)
            for ann in annotations_by_page.get(page_index, []):
                _apply_annotation(page, ann, resolve_stamp_path)

        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out_path))
        return out_path
    finally:
        doc.close()


def _apply_annotation(
    page: fitz.Page,
    ann: AnnotationRecord,
    resolve_stamp_path: Callable[[str], Path | None],
) -> None:
    if isinstance(ann, RectAnnotation):
        _draw_rect(page, ann)
    elif isinstance(ann, TextBoxAnnotation):
        _draw_text_box(page, ann)
    elif isinstance(ann, StampAnnotation):
        _draw_stamp(page, ann, resolve_stamp_path)


def _draw_rect(page: fitz.Page, ann: RectAnnotation) -> None:
    rect = _rect_to_fitz(ann.rect)
    stroke_rgb = _rgb_float(ann.stroke_color)
    stroke_opacity = ann.stroke_color[3] / 255.0
    fill = None
    fill_opacity = 1
    if ann.fill_color is not None:
        fill = _rgb_float(ann.fill_color)
        fill_opacity = ann.fill_color[3] / 255.0
    page.draw_rect(
        rect,
        color=stroke_rgb,
        width=ann.stroke_width,
        stroke_opacity=stroke_opacity,
        fill=fill,
        fill_opacity=fill_opacity,
    )


def _draw_text_box(page: fitz.Page, ann: TextBoxAnnotation) -> None:
    rect = ann.rect.normalized()
    padding = ann.padding
    inset_w = max(0.0, rect.w - (padding * 2.0))
    inset_h = max(0.0, rect.h - (padding * 2.0))
    text_rect = fitz.Rect(
        rect.x + padding,
        rect.y + padding,
        rect.x + padding + inset_w,
        rect.y + padding + inset_h,
    )
    page.insert_textbox(
        text_rect,
        ann.text,
        fontsize=ann.font_size,
        fontname="helv",
    )


def _draw_stamp(
    page: fitz.Page,
    ann: StampAnnotation,
    resolve_stamp_path: Callable[[str], Path | None],
) -> None:
    stamp_path = resolve_stamp_path(ann.stamp_asset_id)
    if stamp_path is None or not stamp_path.exists():
        return
    image_bytes = stamp_path.read_bytes()
    rect = _rect_to_fitz(ann.rect)
    if ann.opacity >= 0.999:
        page.insert_image(rect, stream=image_bytes)
        return
    pixmap = fitz.Pixmap(stream=image_bytes)
    if not pixmap.alpha:
        pixmap = fitz.Pixmap(pixmap, 1)
    alpha_value = max(0, min(255, int(round(ann.opacity * 255))))
    pixmap.set_alpha(bytes(alpha_value))
    page.insert_image(rect, pixmap=pixmap)


def _rect_to_fitz(rect: PtRect) -> fitz.Rect:
    normalized = rect.normalized()
    return fitz.Rect(
        normalized.x,
        normalized.y,
        normalized.x + normalized.w,
        normalized.y + normalized.h,
    )


def _rgb_float(color: tuple[int, int, int, int]) -> tuple[float, float, float]:
    return (color[0] / 255.0, color[1] / 255.0, color[2] / 255.0)
