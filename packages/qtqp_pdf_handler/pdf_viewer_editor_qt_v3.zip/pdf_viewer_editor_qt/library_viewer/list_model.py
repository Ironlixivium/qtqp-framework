"""Qt model for displaying PDFs discovered on disk.

This model is a thin Qt adapter over a list of :class:`PdfCatalogItem`.
It keeps UI widgets decoupled from discovery logic and makes it easy to switch
views (QListView, QTableView, QML) without changing the underlying data.

Design notes:
    - The model stores the canonical list of items.
    - Filtering and sorting should be done with a QSortFilterProxyModel.
"""

from collections.abc import Sequence
from typing import Final

from PySide6.QtCore import QAbstractListModel, QByteArray, QModelIndex, QObject, QPersistentModelIndex, Qt

from .._shared._pdf_catalog_item import PdfCatalogItem


class PdfResourceListModel(QAbstractListModel):
    """A Qt list model exposing :class:`PdfCatalogItem` entries."""

    PATH_ROLE: Final[int] = int(Qt.ItemDataRole.UserRole) + 1
    ITEM_ROLE: Final[int] = int(Qt.ItemDataRole.UserRole) + 2
    CATEGORY_ROLE: Final[int] = int(Qt.ItemDataRole.UserRole) + 3

    def __init__(
        self,
        items: Sequence[PdfCatalogItem] | None = None,
        parent: QObject | None = None,
    ) -> None:
        """Create a list model.

        Args:
            items: Initial items to display.
            parent: Qt parent object.
        """

        super().__init__(parent)
        initial_items: list[PdfCatalogItem] = list(items) if items is not None else []
        self._items: list[PdfCatalogItem] = initial_items

    def rowCount(self, parent: QModelIndex | QPersistentModelIndex | None = None) -> int:
        """Return row count for the root level."""
        if parent is None:
            parent = QModelIndex()

        if parent.isValid():
            return 0
        return len(self._items)

    def data(
        self, index: QModelIndex | QPersistentModelIndex, role: int = int(Qt.ItemDataRole.DisplayRole)
    ) -> object | None:
        """Return data for a given index/role.

        The model supports these roles:
            - DisplayRole: filename (display_name)
            - ToolTipRole: full source path
            - PATH_ROLE: source
            - ITEM_ROLE: PdfCatalogItem instance
            - CATEGORY_ROLE: category label
        """

        if not index.isValid():
            return None

        row: int = index.row()
        if row < 0 or row >= len(self._items):
            return None

        item: PdfCatalogItem = self._items[row]

        value_lookup = {
            int(Qt.ItemDataRole.DisplayRole): lambda: item.display_name,
            int(Qt.ItemDataRole.ToolTipRole): lambda: item.source,
            self.PATH_ROLE: lambda: item.source,
            self.ITEM_ROLE: lambda: item,
            self.CATEGORY_ROLE: lambda: item.category,
        }

        getter = value_lookup.get(role)
        return getter() if getter else None

    def roleNames(self) -> dict[int, QByteArray]:
        """Expose role names for QML and debugging."""

        role_names: dict[int, QByteArray] = dict(super().roleNames())
        role_names[self.PATH_ROLE] = QByteArray(b"source")
        role_names[self.ITEM_ROLE] = QByteArray(b"item")
        role_names[self.CATEGORY_ROLE] = QByteArray(b"category")
        return role_names

    def set_items(self, items: Sequence[PdfCatalogItem]) -> None:
        """Replace the model's items.
        >>> items: New items to display.
        """

        new_items: list[PdfCatalogItem] = list(items)
        self.beginResetModel()
        self._items = new_items
        self.endResetModel()

    def items(self) -> tuple[PdfCatalogItem, ...]:
        """Return an immutable snapshot of the current items."""

        return tuple(self._items)

    def item_at(self, row: int) -> PdfCatalogItem:
        """Return the item at a given row.

        Raises:
            IndexError: If row is out of range.
        """

        return self._items[row]

    def item_from_index(self, index: QModelIndex) -> PdfCatalogItem | None:
        """Return the item for a QModelIndex, or None if invalid."""

        if not index.isValid():
            return None

        row: int = index.row()
        if row < 0 or row >= len(self._items):
            return None

        return self._items[row]
