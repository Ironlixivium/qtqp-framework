import logging
from pathlib import Path
from collections.abc import Callable

from PySide6.QtCore import QObject
from PySide6.QtWidgets import QFileDialog, QWidget

from ..editor import PdfEditor, ToolId
from .._viewer._widget import PdfViewWidget

logger = logging.getLogger(__name__)


class EditorUiController(QObject):
    def __init__(
        self,
        *,
        pdf_viewer: PdfViewWidget,
        dialog_parent: QWidget,
        show_status: Callable[[str], None],
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._pdf_viewer = pdf_viewer
        self._dialog_parent = dialog_parent
        self._show_status = show_status
        self._pdf_editor = PdfEditor(parent=self)
        self._pdf_editor.attach(pdf_viewer)

    def toggle_editing(self) -> None:
        enabled = not self._pdf_viewer.is_editing_enabled()
        self._pdf_viewer.set_editing_enabled(enabled)
        self._pdf_editor.set_enabled(enabled)

    def set_tool(self, tool_id: ToolId) -> None:
        self._pdf_editor.set_tool(tool_id)

    def load_stamp(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self._dialog_parent,
            "Select Stamp Image",
            "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif)",
        )
        if not path:
            return
        try:
            stamp_asset_id = self._pdf_editor.register_stamp_file(path)
            self._pdf_editor.set_active_stamp(stamp_asset_id)
            self._pdf_editor.set_tool(ToolId.STAMP)
        except Exception:
            logger.exception("Failed to load/register stamp")
            return

    def export_pdf(self) -> None:
        desc = self._pdf_viewer.document_descriptor()
        if desc is None:
            self._show_status("No document loaded.")
            return
        default_name = f"{desc.title}-filled.pdf" if desc.title else "exported.pdf"
        save_path, _ = QFileDialog.getSaveFileName(
            self._dialog_parent,
            "Export PDF",
            default_name,
            "PDF Files (*.pdf)",
        )
        if not save_path:
            return
        if not save_path.lower().endswith(".pdf"):
            save_path = f"{save_path}.pdf"
        try:
            self._pdf_editor.export_to_pdf(desc.doc_ref, save_path)
            self._show_status(f"Exported to {Path(save_path).name}.")
        except Exception as exc:
            logger.exception("PDF export failed")
            self._show_status(f"Export failed: {exc}")

    @property
    def pdf_editor(self) -> PdfEditor:
        return self._pdf_editor
