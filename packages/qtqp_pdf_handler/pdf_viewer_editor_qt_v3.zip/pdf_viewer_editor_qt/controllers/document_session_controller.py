from collections.abc import Callable

from PySide6.QtCore import QObject
from PySide6.QtWidgets import QWidget

from ..backends.pdfium import PdfiumRenderProvider
from ..forms.backend import PdfFormBackendCoordinator
from ..forms.qt_workflow import QtPdfFormFillWorkflow
from ..forms.qt_workflow.controller import QThreadRunner
from ..library_viewer.widget import PdfResourceBrowserWidget
from ..services.document_factory import DocumentPayload
from .._viewer.contracts import DescribeFailure, DescribeRequest, DocumentDescriptor
from .._viewer._widget import PdfViewWidget


class DocumentSessionController(QObject):
    def __init__(
        self,
        *,
        pdf_browser: PdfResourceBrowserWidget,
        pdf_viewer: PdfViewWidget,
        dialog_parent: QWidget,
        show_status: Callable[[str], None],
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._pending_doc_request_id: str | None = None
        self._pending_doc_uid: str | None = None
        self._selected_payload: DocumentPayload | None = None

        self._pdf_browser = pdf_browser
        self._pdf_viewer = pdf_viewer
        self._show_status = show_status

        self._pdf_render_provider = PdfiumRenderProvider(parent=self)
        self._form_backend = PdfFormBackendCoordinator()
        self._form_runner = QThreadRunner(backend=self._form_backend, parent=self)
        self._form_workflow = QtPdfFormFillWorkflow(
            runner=self._form_runner,
            dialog_parent=dialog_parent,
            show_status=self._show_status,
            parent=self,
        )

        self._pdf_browser.document_selected.connect(self._on_document_selected)
        self._form_workflow.filled_ready.connect(self._on_filled_pdf_ready)
        self._form_workflow.unchanged_ready.connect(self._on_unchanged_pdf_ready)
        self._form_workflow.failed.connect(self._on_form_workflow_failed)
        self._pdf_render_provider.describe_done.connect(self._on_describe_done)

    def _open_pdf_bytes(self, *, doc_uid: str, doc_ref: bytes, title: str) -> None:
        if self._pending_doc_request_id is not None:
            self._pdf_render_provider.cancel(self._pending_doc_request_id)
        req = DescribeRequest(doc_uid=doc_uid, doc_ref=doc_ref, title=title)
        self._pending_doc_request_id = req.request_id
        self._pending_doc_uid = doc_uid
        self._show_status(f"Loading {title}…")
        self._pdf_viewer.clear_document()
        self._pdf_render_provider.request(req)

    def _open_payload(self, payload: DocumentPayload) -> None:
        self._open_pdf_bytes(
            doc_uid=payload.doc_uid,
            doc_ref=payload.data,
            title=payload.display_name,
        )

    def _on_document_selected(self, payload_obj: object) -> None:
        if not isinstance(payload_obj, DocumentPayload):
            return
        self._selected_payload = payload_obj
        self._form_workflow.start(
            pdf_bytes=payload_obj.data,
            display_name=payload_obj.display_name,
        )

    def _on_filled_pdf_ready(self, pdf_bytes_obj: object) -> None:
        if not isinstance(pdf_bytes_obj, (bytes, bytearray)):
            return
        base = self._selected_payload
        if base is None:
            return
        pdf_bytes = bytes(pdf_bytes_obj)
        new_payload = DocumentPayload(
            doc_uid=f"{base.doc_uid}::filled",
            data=pdf_bytes,
            display_name=base.display_name,
            source=base.source,
        )
        self._open_payload(new_payload)

    def _on_unchanged_pdf_ready(self, pdf_bytes_obj: object) -> None:
        if not isinstance(pdf_bytes_obj, (bytes, bytearray)):
            return
        base = self._selected_payload
        if base is None:
            return
        pdf_bytes = bytes(pdf_bytes_obj)
        if pdf_bytes == base.data:
            self._open_payload(base)
            return
        new_payload = DocumentPayload(
            doc_uid=f"{base.doc_uid}::modified",
            data=pdf_bytes,
            display_name=base.display_name,
            source=base.source,
        )
        self._open_payload(new_payload)

    def _on_form_workflow_failed(self, message: str) -> None:
        self._show_status(message)

    def _on_describe_done(self, obj: object) -> None:
        if isinstance(obj, DocumentDescriptor):
            if obj.doc_uid != self._pending_doc_uid:
                return
            self._pdf_viewer.set_document(obj, self._pdf_render_provider)
            self._show_status(f"Loaded {obj.title}.")
        elif isinstance(obj, DescribeFailure):
            if obj.request_id != self._pending_doc_request_id:
                return
            if obj.doc_uid != self._pending_doc_uid:
                return
            self._show_status(f"Failed to load document: {obj.message}")

    def shutdown(self) -> None:
        self._form_runner.shutdown()
        self._pdf_render_provider.close()
