"""Convenience QObject base class for PdfRenderProvider implementations."""

from __future__ import annotations

import logging
from collections import OrderedDict
from typing import TYPE_CHECKING, cast

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QImage

from .._viewer.contracts import DescribeRequest, RenderKey, RenderRequest, RenderResult

logger = logging.getLogger(__name__)


class _LruImageCache:
    """LRU cache keyed by RenderKey, bounded by approximate byte size."""

    def __init__(self, *, max_bytes: int = 256 * 1024 * 1024) -> None:
        self._max_bytes = max(1, int(max_bytes))
        self._items: OrderedDict[RenderKey, tuple[QImage, int]] = OrderedDict()
        self._total_bytes: int = 0

    def clear(self) -> None:
        self._items.clear()
        self._total_bytes = 0

    def get(self, key: RenderKey) -> QImage | None:
        item = self._items.get(key)
        if item is None:
            return None
        img, _ = item
        self._items.move_to_end(key)
        return img

    def put(self, key: RenderKey, img: QImage) -> None:
        nbytes = self._estimate_bytes(img)
        old = self._items.pop(key, None)
        if old is not None:
            _, old_bytes = old
            self._total_bytes -= old_bytes
        self._items[key] = (img, nbytes)
        self._items.move_to_end(key)
        self._total_bytes += nbytes
        self._evict_if_needed()

    def _estimate_bytes(self, img: QImage) -> int:
        try:
            return max(1, int(img.bytesPerLine()) * int(img.height()))
        except Exception as e:
            logger.warning(e)
            try:
                return max(1, int(img.width()) * int(img.height()) * 4)
            except Exception as e2:
                logger.warning(e2)
                return 1

    def _evict_if_needed(self) -> None:
        while self._total_bytes > self._max_bytes and self._items:
            _, (_, nbytes) = self._items.popitem(last=False)
            self._total_bytes -= nbytes


class PdfRenderProviderBase(QObject):
    """QObject base that satisfies the PdfRenderProvider protocol.

    request() and cancel() are routing layers: they track which kind each
    request_id belongs to, serve render cache hits directly, and delegate
    misses to the four protected hooks below. Subclasses must implement all
    four hooks.
    """

    render_done = Signal(object)    # RenderResult | RenderFailure
    describe_done = Signal(object)  # DocumentDescriptor | DescribeFailure

    def __init__(
        self,
        parent: QObject | None = None,
        *,
        max_cached_render_bytes: int = 256 * 1024 * 1024,
        timeout_s: float = 12.0,
    ) -> None:
        super().__init__(parent)
        self._cache = _LruImageCache(max_bytes=max_cached_render_bytes)
        self._timeout_s = float(timeout_s)

        # Generation counter — increment on worker restart so stale results
        # from the previous worker are silently discarded.
        self._generation: int = 0
        self._request_id_generation: dict[str, int] = {}

    # ---- public API (routing layer) ----

    def request(self, request: RenderRequest | DescribeRequest) -> None:
        if isinstance(request, RenderRequest):
            cached = self._cache.get(request.key)
            if cached is not None:
                self._forget_request_id(request.request_id)
                self.render_done.emit(RenderResult(
                    request_id=request.request_id,
                    key=request.key,
                    image=cached,
                    device_pixel_ratio=float(request.device_pixel_ratio),
                ))
                return
            self._request_render(request)
        else:
            self._request_describe(request)

    def cancel(self, request_id: str) -> None:
        if request_id.startswith("R"):
            self._cancel_render(request_id)
        elif request_id.startswith("D"):
            self._cancel_describe(request_id)

    def clear_cache(self) -> None:
        """Drop cached rendered images."""
        self._cache.clear()

    # ---- subclass hooks ----

    def _request_render(self, request: RenderRequest) -> None:
        raise NotImplementedError

    def _request_describe(self, request: DescribeRequest) -> None:
        raise NotImplementedError

    def _cancel_render(self, request_id: str) -> None:
        raise NotImplementedError

    def _cancel_describe(self, request_id: str) -> None:
        raise NotImplementedError

    # ---- helpers for subclasses ----

    def _forget_request_id(self, request_id: str) -> None:
        """Remove a completed request_id from the routing table."""
        self._request_id_generation.pop(request_id, None)

    def _stamp_generation(self, request_id: str) -> None:
        """Associate *request_id* with the current generation."""
        self._request_id_generation[request_id] = self._generation

    def _is_stale(self, request_id: str) -> bool:
        """Return True if *request_id* belongs to a previous generation."""
        return self._request_id_generation.get(request_id) != self._generation

    def _increment_generation(self) -> None:
        """Bump the generation counter and discard all pending stamps."""
        self._generation += 1
        self._request_id_generation.clear()


if TYPE_CHECKING:
    from .._viewer.contracts import PdfRenderProviderFunctions as _Protocol
    _protocol_check: _Protocol = cast(PdfRenderProviderBase, None)