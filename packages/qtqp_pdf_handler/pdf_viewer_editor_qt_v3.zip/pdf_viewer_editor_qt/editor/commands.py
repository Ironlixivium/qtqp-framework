from dataclasses import dataclass
from typing import Protocol

from .annotation_model import AnnotationRecord
from .annotation_store import AnnotationStore


class Command(Protocol):
    def do(self, store: AnnotationStore) -> None: ...

    def undo(self, store: AnnotationStore) -> None: ...


@dataclass(frozen=True, slots=True)
class AddAnnotationCommand:
    ann: AnnotationRecord

    def do(self, store: AnnotationStore) -> None:
        store.add(self.ann)

    def undo(self, store: AnnotationStore) -> None:
        store.remove(self.ann.id)


@dataclass(frozen=True, slots=True)
class RemoveAnnotationCommand:
    ann: AnnotationRecord

    def do(self, store: AnnotationStore) -> None:
        store.remove(self.ann.id)

    def undo(self, store: AnnotationStore) -> None:
        store.add(self.ann)


@dataclass(frozen=True, slots=True)
class UpdateAnnotationCommand:
    before: AnnotationRecord
    after: AnnotationRecord

    def do(self, store: AnnotationStore) -> None:
        store.update(self.after)

    def undo(self, store: AnnotationStore) -> None:
        store.update(self.before)
