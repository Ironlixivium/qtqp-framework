from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PtPoint:
    x: float
    y: float


@dataclass(frozen=True, slots=True)
class PtRect:
    x: float
    y: float
    w: float
    h: float

    def normalized(self) -> PtRect:
        x, y, w, h = float(self.x), float(self.y), float(self.w), float(self.h)
        if w < 0:
            x += w
            w = -w
        if h < 0:
            y += h
            h = -h
        return PtRect(x, y, w, h)

    def contains(self, point: PtPoint) -> bool:
        return (self.x <= point.x <= self.x + self.w) and (self.y <= point.y <= self.y + self.h)

    def to_tuple(self) -> tuple[float, float, float, float]:
        return (float(self.x), float(self.y), float(self.w), float(self.h))

    @staticmethod
    def from_tuple(tup: tuple[float, float, float, float]) -> PtRect:
        x, y, w, h = tup
        return PtRect(float(x), float(y), float(w), float(h))
