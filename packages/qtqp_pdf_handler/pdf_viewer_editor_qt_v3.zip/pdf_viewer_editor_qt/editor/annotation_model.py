from dataclasses import dataclass, replace
from typing import Any, cast

from .geometry import PtRect


@dataclass(frozen=True, slots=True)
class AnnotationRecord:
    id: str
    page_index: int
    rect: PtRect
    kind: str = ""

    def to_dict(self) -> dict[str, Any]:
        raise NotImplementedError


def _color_to_list(color: tuple[int, int, int, int] | None) -> list[int] | None:
    if color is None:
        return None
    return [int(c) for c in color]


def _color_from_list(color: list[int] | None) -> tuple[int, int, int, int] | None:
    if color is None:
        return None
    return (int(color[0]), int(color[1]), int(color[2]), int(color[3]))


@dataclass(frozen=True, slots=True)
class RectAnnotation(AnnotationRecord):
    stroke_color: tuple[int, int, int, int] = (0, 128, 255, 255)
    stroke_width: float = 1.0
    fill_color: tuple[int, int, int, int] | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "page_index", int(self.page_index))
        object.__setattr__(self, "kind", "rect")
        object.__setattr__(self, "stroke_color", tuple(int(c) for c in self.stroke_color))
        object.__setattr__(self, "stroke_width", float(self.stroke_width))
        if self.fill_color is not None:
            object.__setattr__(self, "fill_color", tuple(int(c) for c in self.fill_color))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "page_index": int(self.page_index),
            "rect": self.rect.to_tuple(),
            "kind": self.kind,
            "stroke_color": _color_to_list(self.stroke_color),
            "stroke_width": float(self.stroke_width),
            "fill_color": _color_to_list(self.fill_color),
        }


@dataclass(frozen=True, slots=True)
class TextBoxAnnotation(AnnotationRecord):
    text: str = ""
    font_size: float = 12.0
    padding: float = 4.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "page_index", int(self.page_index))
        object.__setattr__(self, "kind", "text_box")
        object.__setattr__(self, "text", str(self.text))
        object.__setattr__(self, "font_size", float(self.font_size))
        object.__setattr__(self, "padding", float(self.padding))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "page_index": int(self.page_index),
            "rect": self.rect.to_tuple(),
            "kind": self.kind,
            "text": str(self.text),
            "font_size": float(self.font_size),
            "padding": float(self.padding),
        }


@dataclass(frozen=True, slots=True)
class StampAnnotation(AnnotationRecord):
    stamp_asset_id: str = ""
    opacity: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "page_index", int(self.page_index))
        object.__setattr__(self, "kind", "stamp")
        object.__setattr__(self, "stamp_asset_id", str(self.stamp_asset_id))
        object.__setattr__(self, "opacity", float(self.opacity))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "page_index": int(self.page_index),
            "rect": self.rect.to_tuple(),
            "kind": self.kind,
            "stamp_asset_id": str(self.stamp_asset_id),
            "opacity": float(self.opacity),
        }


def annotation_from_dict(data: dict[str, Any]) -> AnnotationRecord:
    kind = data.get("kind")
    rect = PtRect.from_tuple(cast(tuple[float, float, float, float], tuple(data.get("rect", (0.0, 0.0, 0.0, 0.0)))))
    if kind == "rect":
        return RectAnnotation(
            id=str(data.get("id", "")),
            page_index=int(data.get("page_index", 0)),
            rect=rect,
            stroke_color=_color_from_list(data.get("stroke_color")) or (0, 128, 255, 255),
            stroke_width=float(data.get("stroke_width", 1.0)),
            fill_color=_color_from_list(data.get("fill_color")),
        )
    if kind == "text_box":
        return TextBoxAnnotation(
            id=str(data.get("id", "")),
            page_index=int(data.get("page_index", 0)),
            rect=rect,
            text=str(data.get("text", "")),
            font_size=float(data.get("font_size", 12.0)),
            padding=float(data.get("padding", 4.0)),
        )
    if kind == "stamp":
        return StampAnnotation(
            id=str(data.get("id", "")),
            page_index=int(data.get("page_index", 0)),
            rect=rect,
            stamp_asset_id=str(data.get("stamp_asset_id", "")),
            opacity=float(data.get("opacity", 1.0)),
        )
    # Default to rect if unknown
    return RectAnnotation(id=str(data.get("id", "")), page_index=int(data.get("page_index", 0)), rect=rect)


def replace_rect(ann: AnnotationRecord, rect: PtRect) -> AnnotationRecord:
    if isinstance(ann, RectAnnotation):
        return replace(ann, rect=rect)
    if isinstance(ann, TextBoxAnnotation):
        return replace(ann, rect=rect)
    if isinstance(ann, StampAnnotation):
        return replace(ann, rect=rect)
    return replace(ann, rect=rect)
