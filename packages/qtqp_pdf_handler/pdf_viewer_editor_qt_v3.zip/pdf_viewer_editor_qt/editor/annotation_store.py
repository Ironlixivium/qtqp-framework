from collections.abc import Callable, Iterable
from typing import Any

from .annotation_model import AnnotationRecord


class AnnotationStore:
    def __init__(self) -> None:
        self._doc_uid: str | None = None
        self._items: dict[str, AnnotationRecord] = {}
        self._listeners: list[Callable[[dict[str, Any]], None]] = []

    @property
    def doc_uid(self) -> str | None:
        return self._doc_uid

    def add_listener(self, fn: Callable[[dict[str, Any]], None]) -> None:
        self._listeners.append(fn)

    def _emit(self, event: dict[str, Any]) -> None:
        for fn in list(self._listeners):
            fn(event)

    def set_document(self, doc_uid: str | None) -> None:
        if doc_uid == self._doc_uid:
            return
        self._doc_uid = doc_uid
        self._items.clear()
        self._emit({"type": "reset", "ids": []})

    def reset(self, annotations: Iterable[AnnotationRecord]) -> None:
        self._items = {ann.id: ann for ann in annotations}
        self._emit({"type": "reset", "ids": list(self._items.keys())})

    def add(self, ann: AnnotationRecord) -> None:
        self._items[ann.id] = ann
        self._emit({"type": "added", "ids": [ann.id]})

    def update(self, ann: AnnotationRecord) -> None:
        self._items[ann.id] = ann
        self._emit({"type": "updated", "ids": [ann.id]})

    def remove(self, ann_id: str) -> None:
        if ann_id in self._items:
            self._items.pop(ann_id, None)
            self._emit({"type": "removed", "ids": [ann_id]})

    def get(self, ann_id: str) -> AnnotationRecord | None:
        return self._items.get(ann_id)

    def all(self) -> list[AnnotationRecord]:
        return list(self._items.values())

    def for_page(self, page_index: int) -> list[AnnotationRecord]:
        return [ann for ann in self._items.values() if ann.page_index == page_index]
