from __future__ import annotations

from dataclasses import replace
from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPen, QTransform
from PySide6.QtWidgets import (
    QGraphicsItemGroup,
    QGraphicsPixmapItem,
    QGraphicsRectItem,
    QGraphicsTextItem,
)

from ..annotation_model import AnnotationRecord, RectAnnotation, StampAnnotation, TextBoxAnnotation
from ..geometry import PtRect
from ..stamp_assets import StampRegistry


class EditableTextItem(QGraphicsTextItem):
    def __init__(self, on_commit: Callable[[str], None], parent=None) -> None:
        super().__init__(parent)
        self._on_commit = on_commit

    def focusOutEvent(self, event) -> None:
        if self._on_commit is not None:
            self._on_commit(self.toPlainText())
        super().focusOutEvent(event)


class RectItemWrapper:
    def __init__(self, ann_id: str) -> None:
        self.root = QGraphicsItemGroup()
        self.root.setData(0, ann_id)
        self.rect_item = QGraphicsRectItem(self.root)

    def apply_model(
        self,
        ann: RectAnnotation,
        _stamps: StampRegistry | None = None,
        *,
        is_interactive: bool = False,
    ) -> None:
        r = ann.rect
        self.rect_item.setRect(r.x, r.y, r.w, r.h)
        pen = QPen(QColor(*ann.stroke_color))
        pen.setWidthF(float(ann.stroke_width))
        self.rect_item.setPen(pen)
        if ann.fill_color is None:
            self.rect_item.setBrush(Qt.BrushStyle.NoBrush)
        else:
            self.rect_item.setBrush(QBrush(QColor(*ann.fill_color)))

    def read_back(self, ann: RectAnnotation) -> RectAnnotation:
        r = self.rect_item.rect()
        return replace(ann, rect=PtRect(r.x(), r.y(), r.width(), r.height()))


class TextBoxItemWrapper:
    def __init__(self, ann_id: str, on_commit_text: Callable[[str], None]) -> None:
        self.root = QGraphicsItemGroup()
        self.root.setData(0, ann_id)
        self.rect_item = QGraphicsRectItem(self.root)
        self.text_item = EditableTextItem(on_commit_text, self.root)
        self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

    def enter_edit_mode(self) -> None:
        self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
        self.text_item.setFocus(Qt.FocusReason.MouseFocusReason)

    def exit_edit_mode(self) -> None:
        self.text_item.clearFocus()
        self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

    def apply_model(
        self,
        ann: TextBoxAnnotation,
        _stamps: StampRegistry | None = None,
        *,
        is_interactive: bool = False,
    ) -> None:
        r = ann.rect
        self.rect_item.setRect(r.x, r.y, r.w, r.h)
        pen = QPen(QColor(0, 0, 0, 255))
        pen.setWidthF(1.0)
        self.rect_item.setPen(pen)
        self.rect_item.setBrush(Qt.BrushStyle.NoBrush)

        font = QFont()
        font.setPointSizeF(float(ann.font_size))
        self.text_item.setFont(font)
        self.text_item.setPlainText(ann.text)
        self.text_item.setPos(r.x + ann.padding, r.y + ann.padding)

    def read_back(self, ann: TextBoxAnnotation) -> TextBoxAnnotation:
        r = self.rect_item.rect()
        text = self.text_item.toPlainText()
        return replace(ann, rect=PtRect(r.x(), r.y(), r.width(), r.height()), text=text)


class StampItemWrapper:
    def __init__(self, ann_id: str) -> None:
        self.root = QGraphicsItemGroup()
        self.root.setData(0, ann_id)
        self.pixmap_item = QGraphicsPixmapItem(self.root)
        self._current_asset_id: str | None = None
        self._current_is_preview = False
        self._base_pixmap_w = 0
        self._base_pixmap_h = 0
        self._last_rect: PtRect | None = None

    def _ensure_content(self, stamp_asset_id: str, stamps: StampRegistry, is_preview: bool) -> None:
        if stamp_asset_id == self._current_asset_id and is_preview == self._current_is_preview:
            return
        pix = stamps.get_pixmap(stamp_asset_id, preview=is_preview)
        self.pixmap_item.setPixmap(pix)
        self._base_pixmap_w = pix.width()
        self._base_pixmap_h = pix.height()
        self._current_asset_id = stamp_asset_id
        self._current_is_preview = is_preview

    def _apply_geometry(self, rect: PtRect) -> None:
        self.pixmap_item.setPos(rect.x, rect.y)
        if self._base_pixmap_w > 0 and self._base_pixmap_h > 0:
            sx = rect.w / self._base_pixmap_w
            sy = rect.h / self._base_pixmap_h
            self.pixmap_item.setTransform(QTransform().scale(sx, sy))
        else:
            self.pixmap_item.setTransform(QTransform())
        self._last_rect = rect

    def apply_model(
        self,
        ann: StampAnnotation,
        stamps: StampRegistry | None = None,
        *,
        is_interactive: bool = False,
    ) -> None:
        if stamps is None:
            return
        self._ensure_content(ann.stamp_asset_id, stamps, is_preview=is_interactive)
        self._apply_geometry(ann.rect)
        self.pixmap_item.setOpacity(float(ann.opacity))

    def read_back(self, ann: StampAnnotation) -> StampAnnotation:
        if self._last_rect is None:
            return ann
        return replace(ann, rect=self._last_rect)


def create_wrapper(
    ann: AnnotationRecord,
    *,
    on_commit_text: Callable[[str], None],
    stamps: StampRegistry,
) -> RectItemWrapper | TextBoxItemWrapper | StampItemWrapper:
    if isinstance(ann, TextBoxAnnotation):
        wrapper = TextBoxItemWrapper(ann.id, on_commit_text=on_commit_text)
        wrapper.apply_model(ann, stamps)
        return wrapper
    if isinstance(ann, StampAnnotation):
        wrapper = StampItemWrapper(ann.id)
        wrapper.apply_model(ann, stamps)
        return wrapper
    if isinstance(ann, RectAnnotation):
        wrapper = RectItemWrapper(ann.id)
        wrapper.apply_model(ann, stamps)
        return wrapper
    wrapper = RectItemWrapper(ann.id)
    wrapper.apply_model(ann, stamps)
    return wrapper
