from __future__ import annotations

import logging
from typing import Any

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QGraphicsItemGroup

from ..._viewer._state import LayoutMode
from ..._viewer._widget import PdfViewWidget
from ..annotation_model import AnnotationRecord, TextBoxAnnotation, replace_rect
from ..annotation_store import AnnotationStore
from ..geometry import PtRect
from ..stamp_assets import StampRegistry
from .items import TextBoxItemWrapper, create_wrapper

logger = logging.getLogger(__name__)


class SceneAdapter:
    def __init__(self, store: AnnotationStore, stamps: StampRegistry) -> None:
        self._viewer: PdfViewWidget | None = None
        self._store = store
        self._stamps = stamps
        self._page_groups: list[QGraphicsItemGroup] = []
        self._wrappers: dict[str, Any] = {}
        self._pending_previews: dict[str, PtRect] = {}
        self._preview_timer = QTimer()
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(16)
        self._preview_timer.timeout.connect(self._flush_previews)

    def attach(self, pdf_viewer: PdfViewWidget) -> None:
        self._viewer = pdf_viewer
        pdf_viewer.documentChanged.connect(self.on_document_changed)
        pdf_viewer.layoutChanged.connect(self.sync_layout)
        pdf_viewer.pageChanged.connect(self._on_page_changed)
        self.on_document_changed(pdf_viewer.document_descriptor())

    def page_group(self, page_index: int) -> QGraphicsItemGroup | None:
        if page_index < 0 or page_index >= len(self._page_groups):
            return None
        return self._page_groups[page_index]

    def on_document_changed(self, doc) -> None:
        self._clear_all()
        if self._viewer is None or doc is None:
            return
        root = self._viewer.overlay_root()
        for _i in range(doc.page_count):
            group = QGraphicsItemGroup(root)
            self._page_groups.append(group)
        self.sync_layout(self._viewer.page_rects())

    def sync_layout(self, page_rects: list) -> None:
        if self._viewer is None:
            return
        for i, rect in enumerate(page_rects):
            if i >= len(self._page_groups):
                break
            self._page_groups[i].setPos(rect.topLeft())
        self._apply_single_page_visibility()

    def _apply_single_page_visibility(self) -> None:
        if self._viewer is None:
            return
        if self._viewer.view_state().layout_mode != LayoutMode.SINGLE:
            for group in self._page_groups:
                group.setVisible(True)
            return
        current = self._viewer.view_state().page_index
        for i, group in enumerate(self._page_groups):
            group.setVisible(i == current)

    def _on_page_changed(self, _index: int) -> None:
        self._apply_single_page_visibility()

    def apply_store_reset(self, annotations: list[AnnotationRecord]) -> None:
        self._pending_previews.clear()
        self._preview_timer.stop()
        for wrapper in self._wrappers.values():
            try:
                wrapper.root.scene().removeItem(wrapper.root)
            except Exception:
                logger.exception("SceneAdapter failed to remove item during apply_store_reset")
        self._wrappers.clear()
        for ann in annotations:
            self._create_or_update_item(ann)

    def apply_store_change(self, event: dict[str, Any]) -> None:
        event_type = event.get("type")
        ids = event.get("ids", [])
        if event_type == "reset":
            self.apply_store_reset(self._store.all())
            return
        for ann_id in ids:
            self._pending_previews.pop(ann_id, None)
            if event_type == "removed":
                wrapper = self._wrappers.pop(ann_id, None)
                if wrapper is not None:
                    try:
                        wrapper.root.scene().removeItem(wrapper.root)
                    except Exception:
                        logger.exception("SceneAdapter failed to remove item during removed event")
                continue
            ann = self._store.get(ann_id)
            if ann is None:
                continue
            self._create_or_update_item(ann)

    def update_annotation_preview(self, ann_id: str, rect: PtRect) -> None:
        self._pending_previews[ann_id] = rect
        if not self._preview_timer.isActive():
            self._preview_timer.start()

    def _flush_previews(self) -> None:
        pending = dict(self._pending_previews)
        self._pending_previews.clear()
        for ann_id, rect in pending.items():
            ann = self._store.get(ann_id)
            if ann is None:
                continue
            preview = replace_rect(ann, rect)
            wrapper = self._wrappers.get(ann_id)
            if wrapper is None:
                continue
            wrapper.apply_model(preview, self._stamps, is_interactive=True)

    def enter_text_edit_mode(self, ann_id: str) -> None:
        wrapper = self._wrappers.get(ann_id)
        if isinstance(wrapper, TextBoxItemWrapper):
            if self._viewer is not None:
                view = self._viewer.viewport()
                view.viewport().setFocus(Qt.FocusReason.OtherFocusReason)
                view.setFocus(Qt.FocusReason.OtherFocusReason)
            wrapper.enter_edit_mode()

    def _clear_all(self) -> None:
        self._pending_previews.clear()
        self._preview_timer.stop()
        for wrapper in self._wrappers.values():
            try:
                wrapper.root.scene().removeItem(wrapper.root)
            except Exception:
                logger.exception("SceneAdapter failed to remove item during _clear_all wrappers")
        self._wrappers.clear()
        for group in self._page_groups:
            try:
                group.scene().removeItem(group)
            except Exception:
                logger.exception("SceneAdapter failed to remove item during _clear_all groups")
        self._page_groups.clear()

    def _create_or_update_item(self, ann: AnnotationRecord) -> None:
        group = self.page_group(ann.page_index)
        if group is None:
            return

        def _commit_text(text: str) -> None:
            current = self._store.get(ann.id)
            if isinstance(current, TextBoxAnnotation):
                updated = TextBoxAnnotation(
                    id=current.id,
                    page_index=current.page_index,
                    rect=current.rect,
                    text=text,
                    font_size=current.font_size,
                    padding=current.padding,
                )
                self._store.update(updated)

        wrapper = self._wrappers.get(ann.id)
        if wrapper is None:
            wrapper = create_wrapper(ann, on_commit_text=_commit_text, stamps=self._stamps)
            wrapper.root.setParentItem(group)
            self._wrappers[ann.id] = wrapper
        wrapper.apply_model(ann, self._stamps, is_interactive=False)

    def apply_annotation_rect_final(self, ann_id: str, rect: PtRect) -> None:
        self._pending_previews.pop(ann_id, None)
        ann = self._store.get(ann_id)
        if ann is None:
            return
        final = replace_rect(ann, rect)
        wrapper = self._wrappers.get(ann_id)
        if wrapper is None:
            return
        wrapper.apply_model(final, self._stamps, is_interactive=False)
