from __future__ import annotations

import math

from PySide6.QtCore import QPointF
from PySide6.QtGui import QTransform

from ..annotation_model import AnnotationRecord, replace_rect
from ..commands import UpdateAnnotationCommand
from ..geometry import PtRect


class SelectTool:
    def __init__(self) -> None:
        self._active_id: str | None = None
        self._dragging = False
        self._resize_corner: str | None = None
        self._start_scene_pos = None
        self._start_rect: PtRect | None = None

    def _reset_interaction(self) -> None:
        self._dragging = False
        self._active_id = None
        self._resize_corner = None
        self._start_scene_pos = None
        self._start_rect = None

    def on_mouse_press(self, ctx, scene_pos, buttons, modifiers) -> bool:
        if ctx.viewer is None:
            return False
        item = ctx.viewer.scene().itemAt(scene_pos, QTransform())
        ann_id = None
        while item is not None:
            ann_id = item.data(0)
            if ann_id:
                ann_id = str(ann_id)
                break
            item = item.parentItem()
        if not ann_id:
            ctx.set_selected_id(None)
            return False

        ann = ctx.store.get(ann_id)
        if ann is None:
            return False

        ctx.set_selected_id(ann_id)
        self._active_id = ann_id
        self._start_scene_pos = scene_pos
        self._start_rect = ann.rect
        self._resize_corner = self._pick_corner(ctx, ann, scene_pos)
        self._dragging = True
        return True

    def on_mouse_move(self, ctx, scene_pos, buttons, modifiers) -> bool:
        if ctx.viewer is None:
            self._reset_interaction()
            return True
        if not self._dragging or self._active_id is None or self._start_rect is None or self._start_scene_pos is None:
            self._reset_interaction()
            return False

        ann = ctx.store.get(self._active_id)
        if ann is None:
            self._reset_interaction()
            return True

        new_rect = self._compute_drag_rect(ctx, ann, scene_pos)
        ctx.scene_adapter.update_annotation_preview(self._active_id, new_rect)
        return True

    def on_mouse_release(self, ctx, scene_pos, buttons, modifiers) -> bool:
        if ctx.viewer is None:
            self._reset_interaction()
            return True
        if not self._dragging or self._active_id is None or self._start_rect is None:
            self._reset_interaction()
            return False

        ann = ctx.store.get(self._active_id)
        if ann is None:
            self._reset_interaction()
            return True

        new_rect = self._compute_drag_rect(ctx, ann, scene_pos)
        if new_rect != self._start_rect:
            before = replace_rect(ann, self._start_rect)
            after = replace_rect(ann, new_rect)
            ctx.undo_stack.push(UpdateAnnotationCommand(before=before, after=after))
        else:
            ctx.scene_adapter.apply_annotation_rect_final(self._active_id, self._start_rect)

        self._reset_interaction()
        return True

    def on_key_press(self, ctx, key_event) -> bool:
        if key_event.key() == Qt.Key.Key_Escape and self._dragging:
            self._reset_interaction()
            return True
        return False

    def _pick_corner(self, ctx, ann: AnnotationRecord, scene_pos) -> str | None:
        page_rect = ctx.viewer.page_rect(ann.page_index)
        if page_rect is None:
            return None
        zoom = max(0.01, float(ctx.viewer.viewport().zoom_factor()))
        tolerance_scene = 8.0 / zoom
        corners = {
            "tl": page_rect.topLeft() + QPointF(ann.rect.x, ann.rect.y),
            "tr": page_rect.topLeft() + QPointF(ann.rect.x + ann.rect.w, ann.rect.y),
            "bl": page_rect.topLeft() + QPointF(ann.rect.x, ann.rect.y + ann.rect.h),
            "br": page_rect.topLeft() + QPointF(ann.rect.x + ann.rect.w, ann.rect.y + ann.rect.h),
        }
        for corner, pt in corners.items():
            if math.hypot(scene_pos.x() - pt.x(), scene_pos.y() - pt.y()) <= tolerance_scene:
                return corner
        return None

    def _compute_drag_rect(self, ctx, ann: AnnotationRecord, scene_pos) -> PtRect:
        page_rect = ctx.viewer.page_rect(ann.page_index)
        if page_rect is None or self._start_scene_pos is None or self._start_rect is None:
            return ann.rect

        if self._resize_corner is None:
            dx = scene_pos.x() - self._start_scene_pos.x()
            dy = scene_pos.y() - self._start_scene_pos.y()
            return PtRect(self._start_rect.x + dx, self._start_rect.y + dy, self._start_rect.w, self._start_rect.h)

        page_pos = scene_pos - page_rect.topLeft()
        x, y, w, h = self._start_rect.x, self._start_rect.y, self._start_rect.w, self._start_rect.h
        if self._resize_corner == "tl":
            w = (x + w) - page_pos.x()
            h = (y + h) - page_pos.y()
            x = page_pos.x()
            y = page_pos.y()
        elif self._resize_corner == "tr":
            w = page_pos.x() - x
            h = (y + h) - page_pos.y()
            y = page_pos.y()
        elif self._resize_corner == "bl":
            w = (x + w) - page_pos.x()
            x = page_pos.x()
            h = page_pos.y() - y
        elif self._resize_corner == "br":
            w = page_pos.x() - x
            h = page_pos.y() - y
        return PtRect(x, y, w, h).normalized()
