from __future__ import annotations

import uuid

from PySide6.QtCore import Qt
from PySide6.QtGui import QPen
from PySide6.QtWidgets import QGraphicsRectItem

from ..annotation_model import StampAnnotation
from ..commands import AddAnnotationCommand
from ..geometry import PtRect


class StampTool:
    def __init__(self) -> None:
        self._page_index: int | None = None
        self._start_page_pos = None
        self._preview_item: QGraphicsRectItem | None = None

    def _reset_interaction(self) -> None:
        if self._preview_item is not None:
            scene = self._preview_item.scene()
            if scene is not None:
                scene.removeItem(self._preview_item)
            self._preview_item = None
        self._page_index = None
        self._start_page_pos = None

    def on_mouse_press(self, ctx, scene_pos, buttons, modifiers) -> bool:
        if ctx.viewer is None or ctx.active_stamp_id is None:
            self._reset_interaction()
            return False
        page_index_local = ctx.viewer.page_index_at_scene_pos(scene_pos)
        if page_index_local is None:
            self._reset_interaction()
            return False
        page_pos_local = ctx.viewer.scene_pos_to_page_pos(page_index_local, scene_pos)
        if page_pos_local is None:
            self._reset_interaction()
            return False
        group_local = ctx.scene_adapter.page_group(page_index_local)
        if group_local is None:
            self._reset_interaction()
            return False
        preview_item_local = QGraphicsRectItem(group_local)
        pen = QPen(Qt.GlobalColor.darkRed)
        pen.setStyle(Qt.PenStyle.DashLine)
        preview_item_local.setPen(pen)
        preview_item_local.setRect(page_pos_local.x(), page_pos_local.y(), 1.0, 1.0)
        self._page_index = page_index_local
        self._start_page_pos = page_pos_local
        self._preview_item = preview_item_local
        return True

    def on_mouse_move(self, ctx, scene_pos, buttons, modifiers) -> bool:
        if ctx.viewer is None:
            self._reset_interaction()
            return False
        if self._preview_item is None or self._page_index is None or self._start_page_pos is None:
            self._reset_interaction()
            return False
        page_pos = ctx.viewer.scene_pos_to_page_pos(self._page_index, scene_pos)
        if page_pos is None:
            self._reset_interaction()
            return True
        rect = PtRect(
            self._start_page_pos.x(),
            self._start_page_pos.y(),
            page_pos.x() - self._start_page_pos.x(),
            page_pos.y() - self._start_page_pos.y(),
        ).normalized()
        self._preview_item.setRect(rect.x, rect.y, rect.w, rect.h)
        return True

    def on_mouse_release(self, ctx, scene_pos, buttons, modifiers) -> bool:
        if ctx.viewer is None:
            self._reset_interaction()
            return True
        if self._preview_item is None or self._page_index is None or self._start_page_pos is None:
            self._reset_interaction()
            return False
        if ctx.active_stamp_id is None:
            self._reset_interaction()
            return True
        page_pos = ctx.viewer.scene_pos_to_page_pos(self._page_index, scene_pos)
        if page_pos is None:
            self._reset_interaction()
            return True
        rect = PtRect(
            self._start_page_pos.x(),
            self._start_page_pos.y(),
            page_pos.x() - self._start_page_pos.x(),
            page_pos.y() - self._start_page_pos.y(),
        ).normalized()
        ann = StampAnnotation(
            id=uuid.uuid4().hex,
            page_index=self._page_index,
            rect=rect,
            stamp_asset_id=ctx.active_stamp_id,
        )
        ctx.undo_stack.push(AddAnnotationCommand(ann))
        self._reset_interaction()
        return True

    def on_key_press(self, ctx, key_event) -> bool:
        if key_event.key() == Qt.Key.Key_Escape and self._preview_item is not None:
            self._reset_interaction()
            return True
        return False
