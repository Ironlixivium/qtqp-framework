import logging
from collections.abc import Callable
from dataclasses import dataclass

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtGui import QKeyEvent, QMouseEvent, QTransform
from PySide6.QtWidgets import QGraphicsTextItem

from .._viewer._widget import PdfViewWidget
from .annotation_model import TextBoxAnnotation
from .annotation_store import AnnotationStore
from .graphics.scene_adapter import SceneAdapter
from .stamp_assets import StampRegistry
from .tool_ids import ToolId
from .tools.rect_tool import RectTool
from .tools.select_tool import SelectTool
from .tools.stamp_tool import StampTool
from .tools.text_box_tool import TextBoxTool
from .undo_stack import UndoStack
from ..services.pdf_export_service import export_pdf

logger = logging.getLogger(__name__)


@dataclass
class EditorContext:
    viewer: PdfViewWidget | None
    store: AnnotationStore
    undo_stack: UndoStack
    scene_adapter: SceneAdapter
    active_stamp_id: str | None
    _set_selected: Callable[[str | None], None]

    def set_selected_id(self, ann_id: str | None) -> None:
        self._set_selected(ann_id)


class PdfEditor(QObject):
    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._viewer: PdfViewWidget | None = None
        self._enabled = False
        self._selected_id: str | None = None
        self._active_stamp_id: str | None = None

        self._store = AnnotationStore()
        self._undo = UndoStack(self._store)
        self._stamps = StampRegistry()
        self._scene_adapter = SceneAdapter(self._store, self._stamps)

        self._tools = {
            ToolId.SELECT: SelectTool(),
            ToolId.RECT: RectTool(),
            ToolId.TEXT_BOX: TextBoxTool(),
            ToolId.STAMP: StampTool(),
        }
        self._tool_id = ToolId.SELECT

        self._store.add_listener(self._on_store_change)

    def attach(self, pdf_viewer: PdfViewWidget) -> None:
        self._viewer = pdf_viewer
        self._scene_adapter.attach(pdf_viewer)
        pdf_viewer.documentChanged.connect(self._on_document_changed)
        pdf_viewer.viewport().setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        pdf_viewer.viewport().viewport().setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        pdf_viewer.viewport().installEventFilter(self)
        pdf_viewer.viewport().viewport().installEventFilter(self)

    def set_enabled(self, enabled: bool) -> None:
        was_enabled = self._enabled
        self._enabled = bool(enabled)
        if was_enabled and not self._enabled:
            self._reset_all_tool_interactions()

    def set_tool(self, tool_id: ToolId) -> None:
        if tool_id in self._tools:
            self._reset_all_tool_interactions()
            self._tool_id = tool_id

    def set_active_stamp(self, stamp_asset_id: str | None) -> None:
        self._active_stamp_id = stamp_asset_id

    def register_stamp_file(self, path: str) -> str:
        return self._stamps.register_from_file(path)

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if not self._enabled or self._viewer is None:
            return False

        et = event.type()
        if et == QEvent.Type.Wheel:
            return False

        if et == QEvent.Type.KeyPress:
            focus = self._viewer.scene().focusItem()
            if isinstance(focus, QGraphicsTextItem) and focus.textInteractionFlags():
                return False
            tool = self._tools[self._tool_id]
            assert isinstance(event, QKeyEvent)
            ctx = self._context()
            try:
                return tool.on_key_press(ctx, event)
            except Exception:
                logger.exception(
                    "Tool %s failed on key event %s",
                    self._tool_id,
                    et,
                )
                return False

        if et in (
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseMove,
            QEvent.Type.MouseButtonRelease,
            QEvent.Type.MouseButtonDblClick,
        ):
            assert isinstance(event, QMouseEvent)
            pos = event.position().toPoint()
            scene_pos = self._viewer.viewport().mapToScene(pos)
            tool = self._tools[self._tool_id]
            ctx = self._context()
            if self._is_editable_text_hit(scene_pos):
                return False
            if et == QEvent.Type.MouseButtonDblClick:
                ann_id = self._ann_id_at(scene_pos)
                ann = ctx.store.get(ann_id) if ann_id else None
                if isinstance(ann, TextBoxAnnotation):
                    ctx.scene_adapter.enter_text_edit_mode(ann_id)
                return False
            if et == QEvent.Type.MouseButtonPress:
                view = self._viewer.viewport()
                view.viewport().setFocus(Qt.FocusReason.MouseFocusReason)
                view.setFocus(Qt.FocusReason.MouseFocusReason)
                if self._tool_id == ToolId.TEXT_BOX:
                    ann_id = self._ann_id_at(scene_pos)
                    ann = ctx.store.get(ann_id) if ann_id else None
                    if isinstance(ann, TextBoxAnnotation):
                        self.set_tool(ToolId.SELECT)
                        ctx.set_selected_id(ann_id)
                        ctx.scene_adapter.enter_text_edit_mode(ann_id)
                        return False
                try:
                    return tool.on_mouse_press(ctx, scene_pos, event.buttons(), event.modifiers())
                except Exception:
                    logger.exception(
                        "Tool %s failed on mouse event %s",
                        self._tool_id,
                        et,
                    )
                    return False
            if et == QEvent.Type.MouseMove:
                try:
                    return tool.on_mouse_move(ctx, scene_pos, event.buttons(), event.modifiers())
                except Exception:
                    logger.exception(
                        "Tool %s failed on mouse event %s",
                        self._tool_id,
                        et,
                    )
                    return False
            if et == QEvent.Type.MouseButtonRelease:
                try:
                    return tool.on_mouse_release(ctx, scene_pos, event.buttons(), event.modifiers())
                except Exception:
                    logger.exception(
                        "Tool %s failed on mouse event %s",
                        self._tool_id,
                        et,
                    )
                    return False

        return False

    def _ann_id_at(self, scene_pos) -> str | None:
        if self._viewer is None:
            return None
        item = self._viewer.scene().itemAt(scene_pos, QTransform())
        while item is not None:
            ann_id = item.data(0)
            if ann_id:
                return str(ann_id)
            item = item.parentItem()
        return None

    def _is_editable_text_hit(self, scene_pos) -> bool:
        if self._viewer is None:
            return False
        item = self._viewer.scene().itemAt(scene_pos, QTransform())
        if isinstance(item, QGraphicsTextItem):
            return item.textInteractionFlags() != Qt.TextInteractionFlag.NoTextInteraction
        return False

    def _context(self) -> EditorContext:
        return EditorContext(
            viewer=self._viewer,
            store=self._store,
            undo_stack=self._undo,
            scene_adapter=self._scene_adapter,
            active_stamp_id=self._active_stamp_id,
            _set_selected=self._set_selected_id,
        )

    def _set_selected_id(self, ann_id: str | None) -> None:
        self._selected_id = ann_id

    def _on_document_changed(self, doc) -> None:
        self._reset_all_tool_interactions()
        if doc is None:
            self._store.set_document(None)
            self._store.reset([])
            return
        self._store.set_document(doc.doc_uid)
        self._store.reset([])

    def _reset_all_tool_interactions(self) -> None:
        ctx = self._context()
        for tool in self._tools.values():
            resetter = getattr(tool, "_reset_interaction", None)
            if callable(resetter):
                resetter()

    def _on_store_change(self, event: dict) -> None:
        try:
            self._scene_adapter.apply_store_change(event)
        except Exception:
            logger.exception("SceneAdapter failed to apply store change")
            return

    def export_to_pdf(self, source_pdf_bytes: bytes, output_path: str) -> None:
        export_pdf(
            source_pdf_bytes=source_pdf_bytes,
            annotations=self._store.all(),
            resolve_stamp_path=self._stamps.resolve_path,
            output_path=output_path,
        )
