"""Public PDF viewer widget.

This is the main entry point you embed in your larger app.

Responsibilities:
- expose a stable API (set_document, set_page, set_zoom, ...)
- coordinate between the viewport, scene, and the host-provided render provider
- decide *when* to request renders (visible pages, zoom/rotation changes, etc.)

Non-responsibilities:
- no file I/O
- no PDF backend calls

Editing hook:
- `set_editing_enabled(True)` toggles the overlay root visibility
- `overlay_root()` exposes the overlay group so future tools can add items
"""

from dataclasses import replace

from PySide6.QtCore import QPointF, QRectF, QSizeF, QTimer, Signal
from PySide6.QtWidgets import QVBoxLayout, QWidget

from . import _layout
from ._fit import compute_fit_zoom
from ._interaction import PdfInteractionController
from ._render_coordinator import RenderCoordinator
from ._scene import PdfScene
from ._state import FitMode, LayoutMode, ViewState
from ._viewport import PdfViewport
from .contracts import DocumentDescriptor, PdfRenderProvider


class PdfViewWidget(QWidget):
    """A reusable PDF viewing widget."""

    pageChanged = Signal(int)
    zoomChanged = Signal(float)
    fitModeChanged = Signal(object)  # FitMode
    layoutModeChanged = Signal(object)  # LayoutMode
    editingModeChanged = Signal(bool)
    documentChanged = Signal(object)  # DocumentDescriptor | None
    layoutChanged = Signal(object)  # list[QRectF]

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

        self._scene = PdfScene(self)
        self._viewport = PdfViewport(self)
        self._viewport.setScene(self._scene)

        # Input mapping
        self._interaction = PdfInteractionController(self)
        self._interaction.attach(self._viewport)
        self._interaction.attach(self._viewport.viewport())

        # Wire interaction intents -> widget behavior
        self._interaction.zoom_relative_requested.connect(self._on_zoom_relative)
        self._interaction.zoom_absolute_requested.connect(self._on_zoom_absolute)
        self._interaction.page_step_requested.connect(self._on_page_step)
        self._interaction.go_to_page_requested.connect(self._on_go_to_page)
        self._interaction.fit_mode_requested.connect(self.set_fit_mode)
        self._interaction.pan_mode_requested.connect(self._viewport.set_pan_enabled)

        # Re-render / update current page on viewport changes (coalesced)
        self._viewport_change_timer = QTimer(self)
        self._viewport_change_timer.setSingleShot(True)
        self._viewport_change_timer.timeout.connect(self._on_viewport_changed)
        self._viewport.viewport_resized.connect(self._schedule_viewport_changed)
        self._viewport.verticalScrollBar().valueChanged.connect(self._schedule_viewport_changed)
        self._viewport.horizontalScrollBar().valueChanged.connect(self._schedule_viewport_changed)

        # Layout
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self._viewport)

        # State
        self._state = ViewState()
        self._page_rects: list[QRectF] = []
        self._doc: DocumentDescriptor | None = None

        # Render coordinator owns all request lifecycle logic
        self._renderer = RenderCoordinator(
            scene=self._scene,
            viewport=self._viewport,
            get_state=lambda: self._state,
        )

        # Editing hook
        self._editing_enabled = False
        self._scene.overlay_root().setVisible(False)

        # Guard against re-entrant viewport change handling when fit-to-view
        # updates trigger scroll bar signals.
        self._handling_viewport_change = False
        self._applying_fit_mode = False

    # ---- public API ----

    def viewport(self) -> PdfViewport:
        return self._viewport

    def scene(self) -> PdfScene:
        return self._scene

    def overlay_root(self):
        return self._scene.overlay_root()

    def document_descriptor(self) -> DocumentDescriptor | None:
        return self._doc

    def page_rects(self) -> list[QRectF]:
        return [QRectF(r) for r in self._page_rects]

    def page_rect(self, page_index: int) -> QRectF | None:
        if page_index < 0 or page_index >= len(self._page_rects):
            return None
        return QRectF(self._page_rects[page_index])

    def page_index_at_scene_pos(self, scene_pos: QPointF) -> int | None:
        for i, rect in enumerate(self._page_rects):
            if rect.contains(scene_pos):
                return i
        return None

    def scene_pos_to_page_pos(self, page_index: int, scene_pos: QPointF) -> QPointF | None:
        rect = self.page_rect(page_index)
        if rect is None:
            return None
        return scene_pos - rect.topLeft()

    def page_pos_to_scene_pos(self, page_index: int, page_pos: QPointF) -> QPointF | None:
        rect = self.page_rect(page_index)
        if rect is None:
            return None
        return rect.topLeft() + page_pos

    def set_editing_enabled(self, enabled: bool) -> None:
        self._editing_enabled = bool(enabled)
        self._scene.overlay_root().setVisible(self._editing_enabled)
        self.editingModeChanged.emit(self._editing_enabled)

    def is_editing_enabled(self) -> bool:
        return self._editing_enabled

    def set_document(self, doc: DocumentDescriptor, provider: PdfRenderProvider) -> None:
        """Attach a new document + render provider.

        This resets view state to page 0, recomputes layout, and starts
        requesting visible pages. The provider must already be configured by
        the host app.

        Args:
            doc: Document metadata (page sizes, title, opaque ref).
            provider: Render provider that fulfills RenderRequest objects.
        """
        self._renderer.attach_provider(doc, provider)
        self._doc = doc

        self._state = replace(self._state, page_index=0)
        self._scene.set_pages(doc.page_sizes_pt)
        self._recompute_layout()
        self.documentChanged.emit(self._doc)
        self.layoutChanged.emit(list(self._page_rects))

        # Default behavior: fit width (good for embedding). Host can override.
        self.set_fit_mode(FitMode.FIT_WIDTH)
        self.set_page(0)
        self._renderer.request_visible_pages(self._page_rects, force=True)

    def clear_document(self) -> None:
        """Detach the current document and reset the scene/state."""
        self._renderer.detach_provider()
        self._doc = None
        self._scene.set_pages([])
        self._page_rects = []
        self.documentChanged.emit(None)
        self.layoutChanged.emit([])

    def view_state(self) -> ViewState:
        return self._state

    def set_layout_mode(self, mode: LayoutMode) -> None:
        self._state = self._state.with_layout_mode(mode)
        self.layoutModeChanged.emit(mode)
        self._recompute_layout()
        self._apply_fit_mode_if_needed()
        self._renderer.request_visible_pages(self._page_rects, force=True)

    def set_fit_mode(self, mode: FitMode) -> None:
        self._state = self._state.with_fit_mode(mode)
        self.fitModeChanged.emit(mode)
        self._apply_fit_mode_if_needed()
        self._renderer.request_visible_pages(self._page_rects, force=True)

    def set_page(self, page_index: int) -> None:
        if self._doc is None:
            return

        max_index = max(0, self._doc.page_count - 1)
        pi = max(0, min(int(page_index), max_index))
        self._state = self._state.with_page(pi)

        if self._state.layout_mode == LayoutMode.SINGLE:
            self._scene.set_only_page_visible(pi)
        else:
            for item in self._scene.page_items():
                item.setVisible(True)

        self.pageChanged.emit(pi)
        self._center_on_page(pi)
        self._renderer.request_visible_pages(self._page_rects, force=False)

    def set_zoom(self, zoom: float) -> None:
        self._state = self._state.with_zoom(zoom, fit_mode=FitMode.FREE)
        self.zoomChanged.emit(self._state.zoom)
        self._apply_view_transform()
        self._renderer.request_visible_pages(self._page_rects, force=False)

    def zoom_in(self) -> None:
        self.set_zoom(self._state.zoom * 1.1)

    def zoom_out(self) -> None:
        self.set_zoom(self._state.zoom / 1.1)

    def invalidate_pages(self) -> None:
        """Clear pixmaps and re-request visible pages (does not touch host cache)."""
        self._renderer.invalidate(self._page_rects)

    # ---- internal wiring ----

    def _on_viewport_changed(self) -> None:
        if self._handling_viewport_change:
            return
        self._handling_viewport_change = True
        try:
            self._apply_fit_mode_if_needed()
            self._update_current_page_from_view()
            self._renderer.request_visible_pages(self._page_rects, force=False)
        finally:
            self._handling_viewport_change = False

    def _schedule_viewport_changed(self) -> None:
        if self._viewport_change_timer.isActive():
            return
        self._viewport_change_timer.start(0)

    def _on_zoom_relative(self, factor: float) -> None:
        self.set_zoom(self._state.zoom * float(factor))

    def _on_zoom_absolute(self, zoom: float) -> None:
        self.set_zoom(float(zoom))

    def _on_page_step(self, delta: int) -> None:
        self.set_page(self._state.page_index + int(delta))

    def _on_go_to_page(self, page_index: int) -> None:
        if self._doc is None:
            return
        if page_index < 0:
            self.set_page(self._doc.page_count - 1)
        else:
            self.set_page(page_index)

    def _recompute_layout(self) -> None:
        if self._doc is None:
            return
        self._page_rects = _layout.compute_page_rects(
            self._doc.page_sizes_pt,
            self._state.layout_mode,
            spacing_pt=self._state.page_spacing_pt,
            margin_pt=self._state.margin_pt,
        )
        self._scene.set_layout(self._page_rects)
        scene_rect = _layout.scene_bounding_rect(self._page_rects, margin_pt=self._state.margin_pt)
        self._scene.setSceneRect(scene_rect)
        self.layoutChanged.emit(list(self._page_rects))

    def _apply_fit_mode_if_needed(self) -> None:
        if self._doc is None or not self._page_rects:
            return

        if self._state.fit_mode == FitMode.FREE:
            self._apply_view_transform()
            return

        page_item = self._scene.page_item(self._state.page_index)
        if page_item is None:
            return

        vp_size = QSizeF(self._viewport.viewport().width(), self._viewport.viewport().height())
        zoom = compute_fit_zoom(self._state.fit_mode, page_item.page_rect(), vp_size)

        if self._applying_fit_mode:
            return

        next_zoom = self._state.with_zoom(zoom, fit_mode=self._state.fit_mode).zoom
        if abs(next_zoom - self._state.zoom) < 1e-6:
            return

        self._applying_fit_mode = True
        try:
            self._state = self._state.with_zoom(next_zoom, fit_mode=self._state.fit_mode)
            self.zoomChanged.emit(self._state.zoom)
            self._apply_view_transform()
        finally:
            self._applying_fit_mode = False

    def _apply_view_transform(self) -> None:
        self._viewport.set_zoom_factor(self._state.zoom)

    def _center_on_page(self, page_index: int) -> None:
        item = self._scene.page_item(page_index)
        if item is None:
            return
        rect = item.page_rect()
        visible = self._viewport.visible_scene_rect()
        self._viewport.centerOn(rect.center().x(), rect.top() + visible.height() / 2)

    def _update_current_page_from_view(self) -> None:
        if self._doc is None or not self._page_rects:
            return

        visible = self._viewport.visible_scene_rect()
        center = visible.center()
        best_i = self._state.page_index
        best_dist = float("inf")

        for i, rect in enumerate(self._page_rects):
            if not rect.isValid() or not rect.intersects(visible):
                continue
            dist = abs(rect.center().y() - center.y())
            if dist < best_dist:
                best_dist = dist
                best_i = i

        if best_i != self._state.page_index:
            self._state = self._state.with_page(best_i)
            self.pageChanged.emit(best_i)
