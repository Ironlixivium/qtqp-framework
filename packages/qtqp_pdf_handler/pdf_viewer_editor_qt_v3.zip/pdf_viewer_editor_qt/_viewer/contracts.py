"""Render-provider contract for PdfViewWidget.

This viewer package is intended to be embedded into a larger application.

Separation of concerns:
- The viewer widget (PdfViewWidget) handles layout, interaction, and display.
- The host app handles file I/O and PDF backend integration.

The only integration point is PdfRenderProvider. It receives RenderRequest
instances and emits RenderResult/RenderFailure instances via Qt signals.

Scene coordinates are in *points* (1/72 inch) by default.
"""

from __future__ import annotations

import uuid
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol

from PySide6.QtCore import QSizeF, SignalInstance
from PySide6.QtGui import QImage


@dataclass(frozen=True, slots=True)
class DocumentDescriptor:
    """Document metadata the viewer needs to lay out placeholder pages.

    doc_ref is an opaque handle owned by the host app (path, bytes, db key,
    already-open backend object, etc.). The viewer never inspects it.
    """

    doc_uid: str
    doc_ref: Any
    page_sizes_pt: Sequence[QSizeF]
    title: str = ""

    @property
    def page_count(self) -> int:
        return len(self.page_sizes_pt)


@dataclass(frozen=True, slots=True)
class RenderKey:
    """Identity for a rendered page variant.

    If the host app caches, this is a good cache key.
    """

    doc_uid: str
    page_index: int
    zoom: float
    rotation_deg: int
    target_dpi: float


@dataclass(frozen=True, slots=True)
class RenderRequest:
    """A request to render a page.

    target_dpi is the requested render density. The host may clamp it.
    device_pixel_ratio is included for HiDPI displays.
    """

    doc: DocumentDescriptor
    key: RenderKey
    page_size_pt: QSizeF
    device_pixel_ratio: float = 1.0
    # Optional hint: render size in pixels (if the host prefers that).
    target_size_px: tuple[int, int] | None = None
    request_id: str = field(default_factory=lambda: "R" + uuid.uuid4().hex)


@dataclass(frozen=True, slots=True)
class RenderResult:
    """Successful render."""

    request_id: str
    key: RenderKey
    image: QImage
    device_pixel_ratio: float = 1.0


@dataclass(frozen=True, slots=True)
class RenderFailure:
    """Failed render."""

    request_id: str
    key: RenderKey
    message: str
    exception: BaseException | None = None


@dataclass(frozen=True, slots=True)
class DescribeRequest:
    """A request to describe a document (page count, sizes, title)."""

    doc_uid: str
    doc_ref: bytes
    title: str
    request_id: str = field(default_factory=lambda: "D" + uuid.uuid4().hex)


@dataclass(frozen=True, slots=True)
class DescribeResult:
    """Raw describe result from the worker."""

    request_id: str
    doc_uid: str
    title: str
    page_sizes_pt: list[tuple[float, float]]


@dataclass(frozen=True, slots=True)
class DescribeFailure:
    """Failed document descriptor request."""

    request_id: str
    doc_uid: str
    message: str
    exception: BaseException | None = None


class SignalProtocol(Protocol):
    def __init__(self, *types: type, name: str | None = ..., arguments: list[str] | None = ...) -> None: ...
    def __get__(self, instance: Any | None, owner: Any) -> Any: ...

    def connect(self, slot: object, type: Any = ...) -> Any: ...
    def disconnect(self, slot: object | None = ...) -> bool: ...
    def emit(self, *args: Any) -> None: ...

class PdfRenderProviderSignals(Protocol):
    """Signals mixin for PDF render provider protocol."""
    @property
    def render_done(self) -> SignalInstance: ...    # RenderResult | RenderFailure
    @property
    def describe_done(self) -> SignalInstance: ...  # DocumentDescriptor | DescribeFailure

class PdfRenderProviderFunctions(Protocol):
    """Functions mixin for PDF render provider protocol."""
    def request(self, request: RenderRequest | DescribeRequest) -> None: ...
    def cancel(self, request_id: str) -> None: ...

class PdfRenderProvider(PdfRenderProviderSignals, PdfRenderProviderFunctions):
    """Structural interface the host implements.

    Implementations must:
    - expose render_done signal (emits RenderResult | RenderFailure)
    - expose describe_done signal (emits DocumentDescriptor | DescribeFailure)
    - accept RenderRequest via request(...)
    - optionally support cancellation via cancel(...)
    """
    pass
