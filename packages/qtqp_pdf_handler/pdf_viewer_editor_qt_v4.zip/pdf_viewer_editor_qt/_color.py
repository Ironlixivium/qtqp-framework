from dataclasses import dataclass

from PySide6.QtGui import QColor


@dataclass(frozen=True, slots=True)
class Color:
    Red: int
    Green: int
    Blue: int
    Alpha: int

    def __post_init__(self) -> None:
        for field, value in (("Red", self.Red), ("Green", self.Green), ("Blue", self.Blue), ("Alpha", self.Alpha)):
            if not 0 <= value <= 255:
                raise ValueError(f"Color.{field} must be 0-255, got {value}")

    def to_list(self) -> list[int]:
        return [self.Red, self.Green, self.Blue, self.Alpha]

    @classmethod
    def from_list(cls, lis: list[int]) -> Color:
        if len(lis) < 4:
            raise ValueError(lis)
        return cls(Red=lis[0], Green=lis[1], Blue=lis[2], Alpha=lis[3])

    def to_qcolor(self) -> QColor:
        return QColor(self.Red, self.Green, self.Blue, self.Alpha)
