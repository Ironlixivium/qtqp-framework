"""Template discovery services."""
