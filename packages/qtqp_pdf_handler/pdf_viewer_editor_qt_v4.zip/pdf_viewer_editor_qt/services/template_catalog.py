"""Discover available PDF template files."""

from ..library_viewer._pdf_catalog_item import PdfCatalogItem
from . import app_paths


def discover_templates(*, recursive: bool = True) -> list[PdfCatalogItem]:
    root = app_paths.templates_dir()
    if not root.exists():
        return []

    pattern = "**/*.pdf" if recursive else "*.pdf"
    items: list[PdfCatalogItem] = []

    for path in sorted(root.glob(pattern)):
        if not path.is_file():
            continue
        category = None
        if path.parent != root:
            category = path.parent.name
        items.append(
            PdfCatalogItem(
                display_name=path.name,
                source=str(path.resolve()),
                category=category,
            )
        )

    return items
