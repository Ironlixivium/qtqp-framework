"""Small adapter layer for feeding resource PDFs into a render provider.

This module is intentionally narrow:
    - It defines a protocol for your existing "bytes loader".
    - It defines a simple, provider-ready payload object.
    - It defines a factory that takes a :class:`PdfCatalogItem` and produces a
      payload (bytes + a stable doc_uid).

Why this layer exists:
    Today your renderer may accept raw bytes.
    Tomorrow you might want doc_uid, display name, source, page sizes, flags,
    or a different open mechanism. Keeping this logic centralized lets your UI
    widget stay dumb and stable.
"""


from collections.abc import Callable
from dataclasses import dataclass

from ..library_viewer._pdf_catalog_item import PdfCatalogItem
from .file_handler import PdfBytesLoader

UidStrategy = Callable[[PdfCatalogItem, bytes], str]


def source_uid(item: PdfCatalogItem, _data: bytes) -> str:
    """Default doc_uid strategy.

    Source paths are stable across runs for a given build, and they're
    generally good enough to key provider caches and stale-result checks.
    """

    return item.source


@dataclass(frozen=True, slots=True)
class DocumentPayload:
    """Provider-ready payload.

    Attributes:
        doc_uid:
            A stable identifier for the document. Used for cache keys and stale
            render-result rejection.
        data:
            Raw PDF bytes.
        display_name:
            A UI-friendly label (often the filename).
        source:
            Where the data came from (usually the resource path).
    """

    doc_uid: str
    data: bytes
    display_name: str
    source: str


class DocumentFactory:
    """Create :class:`DocumentPayload` objects from PDF catalog items."""

    def __init__(
        self,
        loader: PdfBytesLoader,
        *,
        uid_strategy: UidStrategy = source_uid,
    ) -> None:
        """Create a document factory.

        Args:
            loader: Your existing PDF bytes loader.
            uid_strategy:
                Function that computes a document UID from the selected item
                and its loaded bytes.
        """

        self._loader: PdfBytesLoader = loader
        self._uid_strategy: UidStrategy = uid_strategy

    def make(self, item: PdfCatalogItem) -> DocumentPayload:
        """Load bytes and build a payload for the renderer.

        Args:
            item: Selected PDF catalog entry.

        Returns:
            A provider-ready payload containing bytes and a stable doc_uid.
        """

        source: str = item.source
        data: bytes = self._loader.read_bytes(source)
        doc_uid: str = self._uid_strategy(item, data)

        return DocumentPayload(
            doc_uid=doc_uid,
            data=data,
            display_name=item.display_name,
            source=source,
        )
