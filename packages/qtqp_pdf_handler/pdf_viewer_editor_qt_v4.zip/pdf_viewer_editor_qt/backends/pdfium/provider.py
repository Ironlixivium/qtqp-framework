"""PDFium-backed render provider for PdfViewWidget.

This object lives in the GUI thread.
All PDFium calls are executed in a single dedicated QThread via
PdfiumRenderWorker.

Responsibilities:
- provide the PdfRenderProvider interface used by PdfViewWidget
- schedule render requests onto the worker thread
- cache rendered QImage results (LRU with byte-size budget)

Non-responsibilities:
- UI, interaction, scene management (handled by PdfViewWidget)
"""

import logging
import time
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QObject, QSizeF, Qt, QThread, QTimer, Signal

from ..._viewer.contracts import (
    DescribeFailure,
    DescribeRequest,
    DescribeResult,
    DocumentDescriptor,
    RenderFailure,
    RenderKey,
    RenderRequest,
    RenderResult,
)
from .._base_provider import PdfRenderProviderBase
from .doc_cache import PdfiumDocumentCache

logger = logging.getLogger(__name__)


class PdfiumRenderProvider(PdfRenderProviderBase):
    """PdfRenderProvider implementation using pypdfium2 (PDFium)."""

    # Cross-thread signals (GUI thread -> worker thread)
    request_render = Signal(RenderRequest)
    cancel_render = Signal(str)
    request_describe = Signal(DescribeRequest)
    cancel_describe = Signal(str)
    shutdown_worker = Signal()

    def __init__(
        self,
        *,
        max_cached_images_bytes: int = 256 * 1024 * 1024,
        max_open_docs: int = 8,
        timeout_s: float = 12.0,
        parent: QObject | None = None,
        fill_color: tuple[int, int, int, int] = (255, 255, 255, 255),
        draw_annots: bool = True,
        may_draw_forms: bool = True,
    ) -> None:
        super().__init__(parent, max_cached_render_bytes=max_cached_images_bytes, timeout_s=timeout_s)

        self._max_open_docs = max_open_docs
        self._fill_color = fill_color
        self._draw_annots = draw_annots
        self._may_draw_forms = may_draw_forms

        # Pending render requests: request_id → (key, started_at)
        self._render_pending: dict[str, tuple[RenderKey, float]] = {}

        # Describe request tracking
        self._describe_request_id_to_ref: dict[str, object] = {}
        self._describe_request_id_to_doc_uid: dict[str, str] = {}
        self._describe_started_at: dict[str, float] = {}

        # Watchdog
        self._watchdog = QTimer(self)
        self._watchdog.setInterval(400)
        self._watchdog.timeout.connect(self._on_watchdog_tick)
        self._watchdog.start()

        # Worker thread
        self._start_worker()

    # ---- subclass hooks ----

    def _request_render(self, request: RenderRequest) -> None:
        self._stamp_generation(request.request_id)
        self._render_pending[request.request_id] = (request.key, time.monotonic())
        self.request_render.emit(request)

    def _cancel_render(self, request_id: str) -> None:
        rid = str(request_id)
        self._render_pending.pop(rid, None)
        self.cancel_render.emit(rid)

    def _request_describe(self, request: DescribeRequest) -> None:
        rid = request.request_id
        self._stamp_generation(rid)
        self._describe_request_id_to_ref[rid] = request.doc_ref
        self._describe_request_id_to_doc_uid[rid] = request.doc_uid
        self._describe_started_at[rid] = time.monotonic()
        self.request_describe.emit(request)

    def _cancel_describe(self, request_id: str) -> None:
        rid = str(request_id)
        self._describe_request_id_to_ref.pop(rid, None)
        self._describe_request_id_to_doc_uid.pop(rid, None)
        self._describe_started_at.pop(rid, None)
        self.cancel_describe.emit(rid)

    def close(self) -> None:
        """Stop the worker thread and release cached documents."""
        self._watchdog.stop()
        self._stop_worker()

        try:
            self.clear_cache()
            self._render_pending.clear()
            self._request_id_generation.clear()
            self._describe_request_id_to_ref.clear()
            self._describe_request_id_to_doc_uid.clear()
            self._describe_started_at.clear()
        except Exception as e:
            logger.log(logging.WARNING, e)

    # ---- worker callbacks ----

    def _on_worker_result_ready(self, result_obj: object) -> None:
        if isinstance(result_obj, RenderResult):
            self._on_render_result(result_obj)
        elif isinstance(result_obj, RenderFailure):
            self._on_render_failure(result_obj)
        elif isinstance(result_obj, DescribeResult):
            self._on_describe_result(result_obj)
        elif isinstance(result_obj, DescribeFailure):
            self._on_describe_failure(result_obj)

    def _on_render_result(self, result: RenderResult) -> None:
        if self._is_stale(result.request_id):
            return
        self._render_pending.pop(result.request_id, None)
        self._forget_request_id(result.request_id)
        self._cache.put(result.key, result.image)
        self.render_done.emit(result)

    def _on_render_failure(self, failure: RenderFailure) -> None:
        if self._is_stale(failure.request_id):
            return
        self._render_pending.pop(failure.request_id, None)
        self._forget_request_id(failure.request_id)
        self.render_done.emit(failure)

    def _on_describe_result(self, result: DescribeResult) -> None:
        if self._is_stale(result.request_id):
            return
        self._describe_started_at.pop(result.request_id, None)
        self._describe_request_id_to_doc_uid.pop(result.request_id, None)
        doc_ref = self._describe_request_id_to_ref.pop(result.request_id, None)
        self._forget_request_id(result.request_id)
        if doc_ref is None:
            return
        page_sizes = [QSizeF(float(w), float(h)) for (w, h) in result.page_sizes_pt]
        self.describe_done.emit(DocumentDescriptor(
            doc_uid=result.doc_uid,
            doc_ref=doc_ref,
            page_sizes_pt=page_sizes,
            title=result.title,
        ))

    def _on_describe_failure(self, failure: DescribeFailure) -> None:
        if self._is_stale(failure.request_id):
            return
        self._describe_started_at.pop(failure.request_id, None)
        self._describe_request_id_to_doc_uid.pop(failure.request_id, None)
        self._describe_request_id_to_ref.pop(failure.request_id, None)
        self._forget_request_id(failure.request_id)
        self.describe_done.emit(failure)

    # ---- watchdog / worker management ----

    def _on_watchdog_tick(self) -> None:
        self._check_render_timeouts()
        self._check_describe_timeouts()

    def _check_render_timeouts(self) -> None:
        if not self._render_pending:
            return

        now = time.monotonic()
        if not any((now - t) > self._timeout_s for _, t in self._render_pending.values()):
            return

        # Worker is hung — fail all pending renders and restart.
        pending = list(self._render_pending.items())
        self._restart_worker()
        msg = "Render timed out; renderer restarted."
        for rid, (key, _) in pending:
            self._forget_request_id(rid)
            logger.log(logging.WARNING, msg)
            self.render_done.emit(RenderFailure(
                request_id=rid,
                key=key,
                message=msg,
                exception=None,
            ))

    def _check_describe_timeouts(self) -> None:
        if not self._describe_started_at:
            return
        now = time.monotonic()
        expired = [
            rid
            for rid, started_at in self._describe_started_at.items()
            if (now - started_at) > self._timeout_s
        ]
        for rid in expired:
            doc_uid = self._describe_request_id_to_doc_uid.get(rid, "")
            self.cancel(rid)
            self.describe_done.emit(DescribeFailure(
                request_id=rid,
                doc_uid=doc_uid,
                message="Describe timed out; request canceled.",
                exception=None,
            ))

    def _start_worker(self) -> None:
        from .worker import PdfiumRenderWorker

        self._thread = QThread(self)
        self._doc_cache = PdfiumDocumentCache(max_docs=self._max_open_docs)
        self._worker = PdfiumRenderWorker(
            self._doc_cache,
            fill_color=self._fill_color,
            draw_annots=self._draw_annots,
            may_draw_forms=self._may_draw_forms,
        )
        self._worker.moveToThread(self._thread)

        self.request_render.connect(self._worker.render, Qt.ConnectionType.QueuedConnection)
        self.cancel_render.connect(self._worker.cancel, Qt.ConnectionType.QueuedConnection)
        self.request_describe.connect(self._worker.describe, Qt.ConnectionType.QueuedConnection)
        self.cancel_describe.connect(self._worker.cancel, Qt.ConnectionType.QueuedConnection)
        self.shutdown_worker.connect(self._worker.shutdown, Qt.ConnectionType.QueuedConnection)

        self._worker.result_ready.connect(self._on_worker_result_ready, Qt.ConnectionType.QueuedConnection)

        self._thread.finished.connect(self._worker.deleteLater)
        self._thread.start()

    def _stop_worker(self) -> None:
        try:
            self.shutdown_worker.emit()
        except Exception as e:
            logger.log(logging.WARNING, e)

        disconnectors: list[tuple[Callable[[object | None], bool], Callable[[Any], None]]] = [
            (self.request_render.disconnect, self._worker.render),
            (self.cancel_render.disconnect, self._worker.cancel),
            (self.request_describe.disconnect, self._worker.describe),
            (self.cancel_describe.disconnect, self._worker.cancel),
            (self._worker.result_ready.disconnect, self._on_worker_result_ready),
            (self.shutdown_worker.disconnect, self._worker.shutdown),
        ]

        for disconnect, function in disconnectors:
            try:
                disconnect(function)
            except (TypeError, RuntimeError) as e:
                logger.log(logging.WARNING, e)

        try:
            self._thread.quit()
            finished = self._thread.wait(500)
        except Exception as e:
            logger.log(logging.WARNING, e)
            finished = False

        if not finished:
            try:
                self._thread.terminate()
                self._thread.wait(500)
            except Exception as e:
                logger.log(logging.WARNING, e)

    def _restart_worker(self) -> None:
        self._stop_worker()
        self._increment_generation()
        self._render_pending.clear()
        self._describe_request_id_to_ref.clear()
        self._describe_request_id_to_doc_uid.clear()
        self._describe_started_at.clear()
        self._start_worker()
