"""Render provider implementations.

These are optional integrations. The core viewer (PdfViewWidget) does not depend
on a specific PDF backend.

Available providers:
- PdfiumRenderProvider: pypdfium2-backed renderer (PDFium)
"""

from .provider import PdfiumRenderProvider

__all__ = ["PdfiumRenderProvider"]
