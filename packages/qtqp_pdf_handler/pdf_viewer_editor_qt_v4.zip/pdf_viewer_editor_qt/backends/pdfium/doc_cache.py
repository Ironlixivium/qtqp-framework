"""PDFium document reuse cache.

This module is intentionally *not* Qt-aware.

Design notes
------------
- PDFium (and pypdfium2) is not thread-safe. If you use a single worker thread
  for all PDFium calls (recommended), this cache should only be touched from
  that same worker thread.
- The cache keeps a small number of PdfDocument objects open to avoid repeated
  parsing / file I/O.

The host app passes an opaque `doc_ref` via DocumentDescriptor.
Common choices:
- str / pathlib.Path: path to a PDF file
- bytes / bytearray: full PDF bytes
- file-like object: readable stream (must stay open)

If you pass a pypdfium2.PdfDocument directly, this cache will *not* close it on
 eviction (it treats it as externally owned).
"""


import logging
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any

import pypdfium2 as pdfium

logger = logging.getLogger(__name__)


def _safe_eq(a: Any, b: Any) -> bool:
    """Best-effort equality check without raising."""
    try:
        if isinstance(a, (bytes, bytearray, memoryview)) or isinstance(b, (bytes, bytearray, memoryview)):
            return a is b
        return a == b
    except Exception:
        return a is b

@dataclass
class _DocEntry:
    ref_key: int
    doc_ref: Any
    doc: pdfium.PdfDocument
    owned: bool



class PdfiumDocumentCache:
    """A tiny LRU cache of open PdfDocument objects."""

    def __init__(self, *, max_docs: int = 8) -> None:
        self._max_docs = max(1, int(max_docs))
        self._docs: OrderedDict[str, _DocEntry] = OrderedDict()

    def __len__(self) -> int:
        return len(self._docs)

    def get(self, doc_uid: str) -> pdfium.PdfDocument | None:
        entry = self._docs.get(doc_uid)
        if entry is None:
            return None
        self._docs.move_to_end(doc_uid)
        return entry.doc

    def get_or_open(self, doc_uid: str, doc_ref: bytes) -> pdfium.PdfDocument:
        """Return a cached open document, or open and cache it."""

        ref_key = id(doc_ref)
        existing = self._docs.get(doc_uid)

        if existing is not None:
            # If the ref points to the same underlying PDF, reuse.
            if existing.ref_key == ref_key or _safe_eq(existing.doc_ref, doc_ref):
                self._docs.move_to_end(doc_uid)
                return existing.doc
            # Same uid but different underlying PDF: replace.
            self._evict_one(doc_uid)

        # Open new
        if isinstance(doc_ref, pdfium.PdfDocument):
            doc = doc_ref
            owned = False
        else:
            doc = pdfium.PdfDocument(doc_ref)
            owned = True

        self._docs[doc_uid] = _DocEntry(ref_key=ref_key, doc_ref=doc_ref, doc=doc, owned=owned)
        self._docs.move_to_end(doc_uid)
        self._enforce_limit()
        return doc

    def close(self, doc_uid: str) -> None:
        """Remove and close a single cached document."""
        self._evict_one(doc_uid)

    def clear(self) -> None:
        """Close and remove all cached documents."""
        for uid in list(self._docs.keys()):
            self._evict_one(uid)

    # ---- internals ----

    def _enforce_limit(self) -> None:
        while len(self._docs) > self._max_docs:
            _, entry = self._docs.popitem(last=False)
            if entry.owned:
                try:
                    entry.doc.close()
                except Exception as e:
                    logger.log(logging.WARNING, e)

    def _evict_one(self, doc_uid: str) -> None:
        entry = self._docs.pop(doc_uid, None)
        if entry is None:
            return
        if entry.owned:
            try:
                entry.doc.close()
            except Exception as e:
                logger.log(logging.WARNING, e)