"""Single-thread PDFium rendering worker.

This worker is designed to live in exactly one QThread.

Why:
- PDFium is not thread-safe. Serializing all PDFium calls through a single
  worker thread avoids a large class of hard-to-debug crashes.

Responsibilities:
- open/reuse PdfDocument objects (via PdfiumDocumentCache)
- render a page to a QImage
- emit RenderResult / RenderFailure

Non-responsibilities:
- scheduling policy, request coalescing, result caching (handled by provider)
"""

import logging

import pypdfium2 as pdfium
from PySide6.QtCore import QObject, Signal, Slot  # type: ignore
from PySide6.QtGui import QImage

from ..._viewer.contracts import (
    DescribeFailure,
    DescribeRequest,
    DescribeResult,
    RenderFailure,
    RenderRequest,
    RenderResult,
)
from .doc_cache import PdfiumDocumentCache

logger = logging.getLogger(__name__)


class PdfiumRenderWorker(QObject):
    """QObject that must be moved to a dedicated QThread."""

    result_ready = Signal(object)  # RenderResult | RenderFailure | DescribeResult | DescribeFailure

    def __init__(
        self,
        doc_cache: PdfiumDocumentCache,
        *,
        fill_color: tuple[int, int, int, int] = (255, 255, 255, 255),
        draw_annots: bool = True,
        may_draw_forms: bool = True,
    ) -> None:
        super().__init__()
        self._doc_cache = doc_cache
        self._fill_color = tuple(int(x) for x in fill_color)
        self._draw_annots = bool(draw_annots)
        self._may_draw_forms = bool(may_draw_forms)
        self._canceled: set[str] = set()
        self._max_canceled: int = 10000

    @Slot(str)
    def cancel(self, request_id: str) -> None:
        self._canceled.add(str(request_id))
        if len(self._canceled) > self._max_canceled:
            self._canceled.clear()

    def _render_page_to_bitmap(
        self, doc: pdfium.PdfDocument, req: RenderRequest
    ) -> tuple[pdfium.PdfPage, pdfium.PdfBitmap]:
        scale = float(req.key.target_dpi) / 72.0  # 72pt = 1 inch
        rotation = int(req.key.rotation_deg)
        page = doc[req.key.page_index]
        bitmap = page.render(
            scale=scale,
            rotation=rotation,
            fill_color=self._fill_color,
            draw_annots=self._draw_annots,
            may_draw_forms=self._may_draw_forms,
        )
        return page, bitmap

    def _bitmap_to_qimage(self, bitmap: pdfium.PdfBitmap, device_pixel_ratio: float) -> QImage:
        arr = bitmap.to_numpy()
        h, w = int(arr.shape[0]), int(arr.shape[1])
        c = int(arr.shape[2]) if len(arr.shape) == 3 else 0

        if c == 3:
            fmt = QImage.Format.Format_RGB888
        elif c == 4:
            fmt = QImage.Format.Format_RGBA8888
        elif c > 4:
            arr = arr[:, :, :4]
            fmt = QImage.Format.Format_RGBA8888
        else:
            raise ValueError(f"Unexpected bitmap array shape: {getattr(arr, 'shape', None)!r}")

        bytes_per_line = int(arr.strides[0])
        img = QImage(arr.data, w, h, bytes_per_line, fmt).copy()
        try:
            img.setDevicePixelRatio(float(device_pixel_ratio))
        except Exception as e:
            logger.log(logging.WARNING, e)
        return img

    @Slot(RenderRequest)
    def render(self, req: RenderRequest) -> None:
        if req.request_id in self._canceled:
            self._canceled.discard(req.request_id)
            return

        page: pdfium.PdfPage | None = None
        bitmap: pdfium.PdfBitmap | None = None

        try:
            doc = self._doc_cache.get_or_open(req.doc.doc_uid, req.doc.doc_ref)
            page, bitmap = self._render_page_to_bitmap(doc, req)
            img = self._bitmap_to_qimage(bitmap, req.device_pixel_ratio)

            if req.request_id in self._canceled:
                self._canceled.discard(req.request_id)
                return

            res = RenderResult(
                request_id=req.request_id,
                key=req.key,
                image=img,
                device_pixel_ratio=float(req.device_pixel_ratio),
            )
            self.result_ready.emit(res)
            self._canceled.discard(req.request_id)

        except Exception as e:
            if req.request_id in self._canceled:
                self._canceled.discard(req.request_id)
                return
            fail = RenderFailure(
                request_id=req.request_id,
                key=req.key,
                message=str(e) or e.__class__.__name__,
                exception=e,
            )
            self.result_ready.emit(fail)
            self._canceled.discard(req.request_id)

        finally:
            # Free PDFium objects ASAP
            try:
                if bitmap is not None:
                    bitmap.close()
            except Exception as e:
                logger.log(logging.WARNING, e)
            try:
                if page is not None:
                    page.close()
            except Exception as e:
                logger.log(logging.WARNING, e)

    @Slot(DescribeRequest)
    def describe(self, req: DescribeRequest) -> None:
        if req.request_id in self._canceled:
            self._canceled.discard(req.request_id)
            return

        try:
            doc = self._doc_cache.get_or_open(req.doc_uid, req.doc_ref)
            page_sizes: list[tuple[float, float]] = []
            page_count = int(len(doc))
            for i in range(page_count):
                if req.request_id in self._canceled:
                    self._canceled.discard(req.request_id)
                    return
                w, h = doc.get_page_size(i)
                page_sizes.append((float(w), float(h)))

            if req.request_id in self._canceled:
                self._canceled.discard(req.request_id)
                return

            res = DescribeResult(
                request_id=req.request_id,
                doc_uid=req.doc_uid,
                title=req.title,
                page_sizes_pt=page_sizes,
            )
            self.result_ready.emit(res)
            self._canceled.discard(req.request_id)
        except Exception as e:
            if req.request_id in self._canceled:
                self._canceled.discard(req.request_id)
                return
            fail = DescribeFailure(
                request_id=req.request_id,
                doc_uid=req.doc_uid,
                message=str(e) or e.__class__.__name__,
                exception=e,
            )
            self.result_ready.emit(fail)
            self._canceled.discard(req.request_id)

    @Slot()
    def shutdown(self) -> None:
        """Close cached documents (run in the worker thread)."""
        try:
            self._doc_cache.clear()
        except Exception as e:
            logger.log(logging.WARNING, e)
        self._canceled.clear()
