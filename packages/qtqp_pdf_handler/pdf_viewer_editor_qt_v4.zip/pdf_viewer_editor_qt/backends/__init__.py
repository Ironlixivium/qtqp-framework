"""Backend provider implementations for PDF rendering and processing."""

