"""Undo/redo stack for editor commands."""

from collections import deque

from .markups._store import MarkupStore
from .commands import Command


class UndoStack:
    def __init__(self, store: MarkupStore) -> None:
        self._store = store
        self._done: deque[Command] = deque()
        self._undone: deque[Command] = deque()

    def push(self, cmd: Command) -> None:
        cmd.do(self._store)
        self._done.append(cmd)
        self._undone.clear()

    def undo(self) -> None:
        if not self._done:
            return
        cmd = self._done.pop()
        cmd.undo(self._store)
        self._undone.append(cmd)

    def redo(self) -> None:
        if not self._undone:
            return
        cmd = self._undone.pop()
        cmd.do(self._store)
        self._done.append(cmd)
