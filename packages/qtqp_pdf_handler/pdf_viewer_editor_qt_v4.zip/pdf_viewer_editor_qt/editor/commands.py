"""Undoable command objects for annotation changes."""

from dataclasses import dataclass
from typing import Protocol

from .markups._models import MarkupBase
from .markups._store import MarkupStore


class Command(Protocol):
    def do(self, store: MarkupStore) -> None: ...

    def undo(self, store: MarkupStore) -> None: ...


@dataclass(frozen=True, slots=True)
class AddAnnotationCommand:
    ann: MarkupBase

    def do(self, store: MarkupStore) -> None:
        store.add(self.ann)

    def undo(self, store: MarkupStore) -> None:
        store.remove(self.ann.id)


@dataclass(frozen=True, slots=True)
class RemoveAnnotationCommand:
    ann: MarkupBase

    def do(self, store: MarkupStore) -> None:
        store.remove(self.ann.id)

    def undo(self, store: MarkupStore) -> None:
        store.add(self.ann)


@dataclass(frozen=True, slots=True)
class UpdateAnnotationCommand:
    before: MarkupBase
    after: MarkupBase

    def do(self, store: MarkupStore) -> None:
        store.update(self.after)

    def undo(self, store: MarkupStore) -> None:
        store.update(self.before)
