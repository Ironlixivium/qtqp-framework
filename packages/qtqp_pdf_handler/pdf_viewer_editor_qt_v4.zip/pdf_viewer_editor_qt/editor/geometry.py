"""Point and rectangle geometry primitives in PDF space."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PtPoint:
    x: float
    y: float


@dataclass(frozen=True, slots=True)
class PtRect:
    x: float
    y: float
    w: float
    h: float

    def normalized(self) -> PtRect:
        x, y, w, h = float(self.x), float(self.y), float(self.w), float(self.h)
        if w < 0:
            x += w
            w = -w
        if h < 0:
            y += h
            h = -h
        return PtRect(x, y, w, h)

    def contains(self, point: PtPoint) -> bool:
        return (self.x <= point.x <= self.x + self.w) and (self.y <= point.y <= self.y + self.h)

    def __iter__(self):
        yield self.x
        yield self.y
        yield self.w
        yield self.h

    def to_list(self) -> list[float]:
        return [float(self.x), float(self.y), float(self.w), float(self.h)]

    @classmethod
    def from_list(cls, li: list[float]) -> PtRect:
        if len(li) < 4:
            raise ValueError(li)
        return cls(float(li[0]), float(li[1]), float(li[2]), float(li[3]))
