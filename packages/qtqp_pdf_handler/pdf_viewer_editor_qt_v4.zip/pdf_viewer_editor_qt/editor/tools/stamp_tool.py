"""Tool for placing stamp annotations."""

import uuid
from typing import TYPE_CHECKING

from PySide6.QtCore import Qt
from PySide6.QtGui import QKeyEvent

from ..markups._models import StampMarkup
from ..commands import AddAnnotationCommand
from ..geometry import PtRect
from .base import ToolBase

if TYPE_CHECKING:
    from PySide6.QtCore import QPointF

    from ..pdf_editor import EditorContext


class StampTool(ToolBase):
    # Default stamp size in PDF points (1 pt = 1/72 inch).
    DEFAULT_WIDTH = 144.0   # 2 inches
    DEFAULT_HEIGHT = 72.0   # 1 inch

    def __init__(self) -> None:
        self._default_size: tuple[float, float] = (self.DEFAULT_WIDTH, self.DEFAULT_HEIGHT)

    def set_default_size(self, width: float, height: float) -> None:
        self._default_size = (width, height)

    def reset_interaction(self) -> None: ...

    def on_mouse_press(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool:
        if ctx.active_stamp_id is None:
            return False
        page_index = ctx.page_index_at(scene_pos)
        if page_index is None:
            return False
        page_pos = ctx.page_pos_at(page_index, scene_pos)
        if page_pos is None:
            return False
        w, h = self._default_size
        rect = PtRect(page_pos.x() - w / 2, page_pos.y() - h / 2, w, h)
        ann = StampMarkup(
            id=uuid.uuid4().hex,
            page_index=page_index,
            rect=rect,
            stamp_asset_id=ctx.active_stamp_id,
        )
        ctx.undo_stack.push(AddAnnotationCommand(ann))
        return True

    def on_mouse_move(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool:
        return False

    def on_mouse_release(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool:
        return False

    def on_key_press(self, ctx: EditorContext, key_event: QKeyEvent) -> bool:
        return False
