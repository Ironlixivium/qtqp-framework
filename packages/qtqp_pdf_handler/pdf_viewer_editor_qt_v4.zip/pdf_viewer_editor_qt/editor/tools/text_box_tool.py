"""Tool for placing text box annotations."""

import uuid
from typing import TYPE_CHECKING

from PySide6.QtCore import Qt

from ..markups._models import TextBoxMarkup
from ..commands import AddAnnotationCommand
from ..geometry import PtRect
from .draw_rect_base import DrawRectToolBase

if TYPE_CHECKING:
    from ..pdf_editor import EditorContext


class TextBoxTool(DrawRectToolBase):
    def _pen_color(self) -> Qt.GlobalColor:
        return Qt.GlobalColor.darkGreen

    def _commit(self, ctx: EditorContext, page_index: int, rect: PtRect) -> None:
        ann_id = uuid.uuid4().hex
        ann = TextBoxMarkup(id=ann_id, page_index=page_index, rect=rect, text="")
        ctx.undo_stack.push(AddAnnotationCommand(ann))
        ctx.scene_adapter.enter_text_edit_mode(ann_id)
