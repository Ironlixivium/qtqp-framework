"""Base classes and protocol for editor tools."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Protocol

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QKeyEvent

if TYPE_CHECKING:
    from ..pdf_editor import EditorContext


class ToolProtocol(Protocol):
    """Structural protocol for tool compatibility checks."""

    def on_mouse_press(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool: ...

    def on_mouse_move(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool: ...

    def on_mouse_release(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool: ...

    def on_key_press(self, ctx: EditorContext, key_event: QKeyEvent) -> bool: ...


class ToolBase(ABC):
    """Abstract base class that all editor tools must subclass."""

    @abstractmethod
    def on_mouse_press(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool: ...

    @abstractmethod
    def on_mouse_move(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool: ...

    @abstractmethod
    def on_mouse_release(
        self, ctx: EditorContext, scene_pos: QPointF, buttons: Qt.MouseButton, modifiers: Qt.KeyboardModifier
    ) -> bool: ...

    @abstractmethod
    def on_key_press(self, ctx: EditorContext, key_event: QKeyEvent) -> bool: ...

    @abstractmethod
    def reset_interaction(self) -> None:
        """Clean up any in-progress interaction state."""
        ...
