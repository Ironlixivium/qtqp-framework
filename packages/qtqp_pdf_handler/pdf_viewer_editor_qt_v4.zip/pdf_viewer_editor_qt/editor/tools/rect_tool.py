"""Tool for drawing rectangle annotations."""

import uuid
from typing import TYPE_CHECKING

from PySide6.QtCore import Qt

from ..markups._models import RectMarkup
from ..commands import AddAnnotationCommand
from ..geometry import PtRect
from .draw_rect_base import DrawRectToolBase

if TYPE_CHECKING:
    from ..pdf_editor import EditorContext


class RectTool(DrawRectToolBase):
    def _pen_color(self) -> Qt.GlobalColor:
        return Qt.GlobalColor.blue

    def _commit(self, ctx: EditorContext, page_index: int, rect: PtRect) -> None:
        ann = RectMarkup(id=uuid.uuid4().hex, page_index=page_index, rect=rect)
        ctx.undo_stack.push(AddAnnotationCommand(ann))
