"""Protocol describing viewer capabilities needed by the editor."""

from typing import Protocol

from PySide6.QtCore import QPointF, QRectF, SignalInstance
from PySide6.QtWidgets import QGraphicsItemGroup, QGraphicsScene, QGraphicsView

from .._viewer._state import ViewState
from .._viewer.contracts import DocumentDescriptor


class PdfViewerSignals(Protocol):
    @property
    def documentChanged(self) -> SignalInstance: ...  # Signal(object)
    @property
    def layoutChanged(self) -> SignalInstance: ...  # Signal(object)
    @property
    def pageChanged(self) -> SignalInstance: ...  # Signal(int)


class PdfViewerNonSignals(Protocol):
    def viewport(self) -> QGraphicsView: ...
    def scene(self) -> QGraphicsScene: ...
    def overlay_root(self) -> QGraphicsItemGroup: ...
    def document_descriptor(self) -> DocumentDescriptor | None: ...
    def page_rects(self) -> list[QRectF]: ...
    def view_state(self) -> ViewState: ...
    def page_index_at_scene_pos(self, scene_pos: QPointF) -> int | None: ...
    def scene_pos_to_page_pos(self, page_index: int, scene_pos: QPointF) -> QPointF | None: ...
    def page_rect(self, page_index: int) -> QRectF | None: ...


class PdfViewerProtocol(PdfViewerSignals, PdfViewerNonSignals):
    pass