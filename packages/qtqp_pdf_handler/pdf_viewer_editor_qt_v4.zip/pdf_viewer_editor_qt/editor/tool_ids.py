"""Enumeration of editor tool identifiers."""

from enum import Enum, auto


class ToolId(Enum):
    SELECT = auto()
    RECT = auto()
    TEXT_BOX = auto()
    STAMP = auto()
