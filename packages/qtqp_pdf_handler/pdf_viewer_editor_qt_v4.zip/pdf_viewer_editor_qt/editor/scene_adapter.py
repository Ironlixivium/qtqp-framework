"""Adapter that syncs annotations with the Qt graphics scene."""


import logging

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtWidgets import QGraphicsItemGroup

from .._viewer._state import LayoutMode
from .._viewer.contracts import DocumentDescriptor
from ._viewer_protocol import PdfViewerProtocol
from .geometry import PtRect
from .markups._models import Markup, TextBoxMarkup
from .markups._store import MarkupStore, StoreEvent
from .markups.qt_graphics._wrappers import ItemWrapper, TextBoxItemWrapper, create_wrapper
from .stamp_assets import StampRegistry

logger = logging.getLogger(__name__)


class SceneAdapter:
    def __init__(self, store: MarkupStore, stamps: StampRegistry, viewer: PdfViewerProtocol) -> None:
        self._viewer = viewer
        self._viewer.documentChanged.connect(self.on_document_changed)
        self._viewer.layoutChanged.connect(self.sync_layout)
        self._viewer.pageChanged.connect(self._on_page_changed)
        self._store = store
        self._stamps = stamps
        self._page_groups: list[QGraphicsItemGroup] = []
        self._wrappers: dict[str, ItemWrapper] = {}
        self._pending_previews: dict[str, PtRect] = {}
        self._preview_timer = QTimer()
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(16)
        self._preview_timer.timeout.connect(self._flush_previews)

    def page_group(self, page_index: int) -> QGraphicsItemGroup | None:
        if page_index < 0 or page_index >= len(self._page_groups):
            return None
        return self._page_groups[page_index]

    def on_document_changed(self, doc: DocumentDescriptor | None) -> None:
        self._clear_all()
        if doc is None:
            return
        root = self._viewer.overlay_root()
        for _i in range(doc.page_count):
            group = QGraphicsItemGroup(root)
            self._page_groups.append(group)
        self.sync_layout(self._viewer.page_rects())

    def sync_layout(self, page_rects: list[QRectF]) -> None:
        for i, rect in enumerate(page_rects):
            if i >= len(self._page_groups):
                break
            self._page_groups[i].setPos(rect.topLeft())
        self._apply_single_page_visibility()

    def _apply_single_page_visibility(self) -> None:
        if self._viewer.view_state().layout_mode != LayoutMode.SINGLE:
            for group in self._page_groups:
                group.setVisible(True)
            return
        current = self._viewer.view_state().page_index
        for i, group in enumerate(self._page_groups):
            group.setVisible(i == current)

    def _on_page_changed(self, _index: int) -> None:
        self._apply_single_page_visibility()

    def apply_store_reset(self, markups: list[Markup]) -> None:
        self._pending_previews.clear()
        self._preview_timer.stop()
        for wrapper in self._wrappers.values():
            try:
                wrapper.scene().removeItem(wrapper)
            except Exception:
                logger.exception("SceneAdapter failed to remove item during apply_store_reset")
        self._wrappers.clear()
        for markup in markups:
            self._create_or_update_item(markup)

    def apply_store_change(self, event: StoreEvent) -> None:
        event_type = event["type"]
        ids = event["ids"]
        if event_type == "reset":
            self.apply_store_reset(self._store.all())
            return
        for markup_id in ids:
            self._pending_previews.pop(markup_id, None)
            if event_type == "removed":
                wrapper = self._wrappers.pop(markup_id, None)
                if wrapper is not None:
                    try:
                        wrapper.scene().removeItem(wrapper)
                    except Exception:
                        logger.exception("SceneAdapter failed to remove item during removed event")
                continue
            markup = self._store.get(markup_id)
            if markup is None:
                continue
            self._create_or_update_item(markup)

    def update_annotation_preview(self, ann_id: str, rect: PtRect) -> None:
        self._pending_previews[ann_id] = rect
        if not self._preview_timer.isActive():
            self._preview_timer.start()

    def _flush_previews(self) -> None:
        pending = dict(self._pending_previews)
        self._pending_previews.clear()
        for ann_id, rect in pending.items():
            markup = self._store.get(ann_id)
            if markup is None:
                continue
            preview = markup.replace_rect(rect)
            wrapper = self._wrappers.get(ann_id)
            if wrapper is None:
                continue
            wrapper.apply_markup(preview, stamps=self._stamps, is_interactive=True)  # type: ignore[arg-type]

    def enter_text_edit_mode(self, ann_id: str) -> None:
        wrapper = self._wrappers.get(ann_id)
        if isinstance(wrapper, TextBoxItemWrapper):
            self._viewer.viewport().viewport().setFocus(Qt.FocusReason.OtherFocusReason)
            wrapper.enter_edit_mode()

    def _clear_all(self) -> None:
        self._pending_previews.clear()
        self._preview_timer.stop()
        for wrapper in self._wrappers.values():
            try:
                wrapper.scene().removeItem(wrapper)
            except Exception:
                logger.exception("SceneAdapter failed to remove item during _clear_all wrappers")
        self._wrappers.clear()
        for group in self._page_groups:
            try:
                group.scene().removeItem(group)
            except Exception:
                logger.exception("SceneAdapter failed to remove item during _clear_all groups")
        self._page_groups.clear()

    def _create_or_update_item(self, markup: Markup) -> None:
        group = self.page_group(markup.page_index)
        if group is None:
            return

        def _commit_text(text: str) -> None:
            current = self._store.get(markup.id)
            if isinstance(current, TextBoxMarkup):
                updated = TextBoxMarkup(
                    id=current.id,
                    page_index=current.page_index,
                    rect=current.rect,
                    text=text,
                    font_size=current.font_size,
                    padding=current.padding,
                )
                self._store.update(updated)

        wrapper = self._wrappers.get(markup.id)
        if wrapper is None:
            wrapper = create_wrapper(markup, on_commit_text=_commit_text, stamps=self._stamps)
            wrapper.setParentItem(group)
            self._wrappers[markup.id] = wrapper
        wrapper.apply_markup(markup, stamps=self._stamps, is_interactive=False)  # type: ignore[arg-type]

    def apply_annotation_rect_final(self, ann_id: str, rect: PtRect) -> None:
        self._pending_previews.pop(ann_id, None)
        markup = self._store.get(ann_id)
        if markup is None:
            return
        final = markup.replace_rect(rect)
        wrapper = self._wrappers.get(ann_id)
        if wrapper is None:
            return
        wrapper.apply_markup(final, stamps=self._stamps, is_interactive=False)  # type: ignore[arg-type]
