from abc import ABC, abstractmethod
from dataclasses import dataclass, replace
from typing import Any, ClassVar, Literal, Self, overload

from ..geometry import PtRect
from ._typing import MarkupDictBaseFields, MarkupKind, RectMarkupDict, StampMarkupDict, TextMarkupDict

type MarkupDict = RectMarkupDict | TextMarkupDict | StampMarkupDict

@dataclass(frozen=True, slots=True)
class MarkupBase(ABC):
    id: str
    page_index: int
    rect: PtRect
    kind: ClassVar[MarkupKind]

    @abstractmethod
    @classmethod
    def from_dict(cls, markup_dict: Any) -> MarkupBase: ...

    @abstractmethod
    def to_dict(self) -> MarkupDict: ...

    @staticmethod
    def _fields_from_dict(markup_dict: MarkupDict) -> tuple[str, int, PtRect]:
        id=str(markup_dict.get("id", ""))
        page_index=int(markup_dict["page_index"])
        rect=PtRect.from_list(markup_dict["rect"])
        return id, page_index, rect

    def replace_rect(self, rect: PtRect) -> Self:
        return replace(self, rect=rect)

    @overload
    def _fields_to_dict(self, kind: Literal[MarkupKind.RECT]) -> RectMarkupDict: ...
    
    @overload
    def _fields_to_dict(self, kind: Literal[MarkupKind.STAMP]) -> StampMarkupDict: ...
    
    @overload
    def _fields_to_dict(self, kind: Literal[MarkupKind.TEXT]) -> TextMarkupDict: ...
    

    def _fields_to_dict(self, kind: MarkupKind) -> MarkupDictBaseFields:
        return {
            "id": self.id,
            "page_index": self.page_index,
            "rect": self.rect.to_list(),
            "kind": kind.value,
        }
