"""TypedDicts for markup serialization."""
from enum import StrEnum, auto
from typing import TYPE_CHECKING, Any, Literal, TypedDict, assert_never


class MarkupKind(StrEnum):
    RECT = auto()
    STAMP = auto()
    TEXT = auto()

type KindLiteral = Literal[
    "rect",
    "stamp",
    "text",
]

class MarkupDictBaseFields(TypedDict):
    id: str
    page_index: int
    rect: list[float]
    kind: Any

class RectMarkupDict(MarkupDictBaseFields, closed=True):
    kind: Literal["rect"]
    stroke_color: list[int]
    stroke_width: float
    fill_color: list[int]

class StampMarkupDict(MarkupDictBaseFields, closed=True):
    kind: Literal["stamp"]
    stamp_asset_id: str
    opacity: float

class TextMarkupDict(MarkupDictBaseFields, closed=True):
    kind: Literal["text"]
    text: str
    text_color: list[int]
    font_size: float
    padding: float

type MarkupDict = RectMarkupDict | TextMarkupDict | StampMarkupDict


if TYPE_CHECKING:
    def check_kind_enum_to_literal(ke: MarkupKind) -> KindLiteral:
        match ke:
            case MarkupKind.RECT:
                return "rect"
            case MarkupKind.STAMP:
                return "stamp"
            case MarkupKind.TEXT:
                return "text"
            case _:
                assert_never()

    def check_kind_literal_to_enum(kl: KindLiteral) -> MarkupKind:
        match kl:
            case "rect":
                return MarkupKind.RECT
            case "stamp":
                return MarkupKind.STAMP
            case "text":
                return MarkupKind.TEXT
            case _:
                assert_never()

    def check_dict_to_enum(md: MarkupDict) -> MarkupKind:
        kind = md["kind"]
        match kind:
            case "rect":
                return MarkupKind(kind)
            case "stamp":
                return MarkupKind(kind)
            case "text":
                return MarkupKind(kind)
            case _:
                assert_never()
