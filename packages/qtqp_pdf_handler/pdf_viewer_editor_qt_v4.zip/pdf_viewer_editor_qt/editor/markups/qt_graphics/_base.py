"""
Base class and protocol for Qt graphics item wrappers.
I would make it an ABC, but that conflicts with Qt framework
"""
from dataclasses import replace
from typing import Protocol, runtime_checkable

from PySide6.QtWidgets import QGraphicsRectItem

from ...geometry import PtRect
from ...stamp_assets import StampRegistry
from .._models import Markup


class BaseRectWrapper[M: Markup](QGraphicsRectItem):
    """QGraphicsRectItem base that handles markup id, rect geometry, and read_back."""

    def __init__(self, markup: Markup) -> None:
        super().__init__()
        self.id = markup.id

    def _apply_rect(self, markup: Markup) -> None:
        self.setRect(*markup.rect)

    def read_back(self, markup: M) -> M:
        r = self.rect()
        return replace(markup, rect=PtRect(r.x(), r.y(), r.width(), r.height()))
    
    def apply_markup(self, markup: M, *, stamps: StampRegistry | None = None, is_interactive: bool = False) -> None: ...


@runtime_checkable
class ItemWrapper[M](Protocol):
    id: str
    def apply_markup(self, markup: M, *, stamps: StampRegistry | None = None, is_interactive: bool = False) -> None: ...
    def read_back(self, markup: M) -> M: ...
