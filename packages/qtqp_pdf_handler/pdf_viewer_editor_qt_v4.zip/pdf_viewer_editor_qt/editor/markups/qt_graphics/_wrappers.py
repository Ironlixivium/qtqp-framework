"""Qt graphics item wrappers for rendering and editing annotations."""


from collections.abc import Callable
from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QFocusEvent, QFont, QPen, QTransform
from PySide6.QtWidgets import (
    QGraphicsItem,
    QGraphicsPixmapItem,
    QGraphicsTextItem,
)

from ...geometry import PtRect
from ...stamp_assets import StampRegistry
from .._models import Markup, RectMarkup, StampMarkup, TextBoxMarkup
from ._base import BaseRectWrapper


class RectItemWrapper(BaseRectWrapper[RectMarkup]):
    def __init__(self, markup: RectMarkup) -> None:
        super().__init__(markup)
        self.apply_markup(markup)

    def apply_markup(
        self,
        markup: RectMarkup,
        *,
        stamps: StampRegistry | None = None,
        is_interactive: bool = False,
    ) -> None:
        self._apply_rect(markup)
        pen = QPen(markup.stroke_color.to_qcolor())
        pen.setWidthF(markup.stroke_width)
        self.setPen(pen)
        if markup.fill_color.Alpha == 0:
            self.setBrush(Qt.BrushStyle.NoBrush)
        else:
            self.setBrush(QBrush(markup.fill_color.to_qcolor()))


class EditableTextItem(QGraphicsTextItem):
    def __init__(self, on_commit: Callable[[str], None], parent: QGraphicsItem | None = None) -> None:
        super().__init__(parent=parent)
        self._on_commit = on_commit

    def focusOutEvent(self, event: QFocusEvent) -> None:
        self._on_commit(self.toPlainText())
        super().focusOutEvent(event)


class TextBoxItemWrapper(BaseRectWrapper[TextBoxMarkup]):
    def __init__(self, markup: TextBoxMarkup, on_commit_text: Callable[[str], None]) -> None:
        super().__init__(markup)
        self.text_item = EditableTextItem(on_commit_text, self)
        self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self.apply_markup(markup)

    def enter_edit_mode(self) -> None:
        self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
        self.text_item.setFocus(Qt.FocusReason.MouseFocusReason)

    def exit_edit_mode(self) -> None:
        self.text_item.clearFocus()
        self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

    def apply_markup(
        self,
        markup: TextBoxMarkup,
        *,
        stamps: StampRegistry | None = None,
        is_interactive: bool = False,
    ) -> None:
        self._apply_rect(markup)
        pen = QPen(markup.text_color.to_qcolor())
        pen.setWidthF(1.0)
        self.setPen(pen)
        self.setBrush(Qt.BrushStyle.NoBrush)
        font = QFont()
        font.setPointSizeF(float(markup.font_size))
        self.text_item.setFont(font)
        self.text_item.setPlainText(markup.text)
        self.text_item.setPos(markup.rect.x + markup.padding, markup.rect.y + markup.padding)

    def read_back(self, markup: TextBoxMarkup) -> TextBoxMarkup:
        result = super().read_back(markup)
        return replace(result, text=self.text_item.toPlainText())


class StampItemWrapper(BaseRectWrapper[StampMarkup]):
    def __init__(self, markup: StampMarkup, *, stamps: StampRegistry) -> None:
        super().__init__(markup)
        self.pixmap_item = QGraphicsPixmapItem(self)
        self._current_asset_id: str | None = None
        self._current_is_preview = False
        self._base_pixmap_w = 0
        self._base_pixmap_h = 0
        self.apply_markup(markup, stamps=stamps)

    def _ensure_content(self, stamp_asset_id: str, stamps: StampRegistry, is_preview: bool) -> None:
        if stamp_asset_id == self._current_asset_id and is_preview == self._current_is_preview:
            return
        pix = stamps.get_pixmap(stamp_asset_id, preview=is_preview)
        self.pixmap_item.setPixmap(pix)
        self._base_pixmap_w = pix.width()
        self._base_pixmap_h = pix.height()
        self._current_asset_id = stamp_asset_id
        self._current_is_preview = is_preview

    def _apply_geometry(self, rect: PtRect) -> None:
        self.pixmap_item.setPos(rect.x, rect.y)
        if self._base_pixmap_w > 0 and self._base_pixmap_h > 0:
            sx = rect.w / self._base_pixmap_w
            sy = rect.h / self._base_pixmap_h
            self.pixmap_item.setTransform(QTransform().scale(sx, sy))
        else:
            self.pixmap_item.setTransform(QTransform())

    def apply_markup(
        self,
        markup: StampMarkup,
        *,
        stamps: StampRegistry | None = None,
        is_interactive: bool = False,
    ) -> None:
        if stamps is None:
            return
        self._ensure_content(markup.stamp_asset_id, stamps, is_preview=is_interactive)
        self._apply_rect(markup)
        self.setPen(Qt.PenStyle.NoPen)
        self.setBrush(Qt.BrushStyle.NoBrush)
        self._apply_geometry(markup.rect)
        self.setOpacity(float(markup.opacity))

    # read_back inherited from BaseRectWrapper[StampMarkup]


type ItemWrapper = RectItemWrapper | TextBoxItemWrapper | StampItemWrapper


def create_wrapper(
    markup: Markup,
    *,
    on_commit_text: Callable[[str], None] = lambda t: None,
    stamps: StampRegistry,
) -> ItemWrapper:
    match markup:
        case RectMarkup():
            return RectItemWrapper(markup)
        case StampMarkup():
            return StampItemWrapper(markup, stamps=stamps)
        case TextBoxMarkup():
            return TextBoxItemWrapper(markup, on_commit_text=on_commit_text)
