"""Annotation data models and serialization helpers."""

import logging
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any, ClassVar, Literal

from ..._color import Color
from ._base import MarkupBase, MarkupKind
from ._typing import RectMarkupDict, StampMarkupDict, TextMarkupDict

logger = logging.getLogger(__name__)

_BLACK = Color(Red=0, Green=0, Blue=0, Alpha=255)
_TRANSPARENT = Color(Red=0, Green=0, Blue=0, Alpha=0)

def _parse_field[T](
    source_dict: Mapping[str, Any],
    field: str,
    converter: Callable[[Any], T],
    default: T,
    errors: type[Exception] | tuple[type[Exception], ...] = Exception,
    *,
    context: str,
) -> T:
    if field in source_dict:
        try:
            return converter(source_dict[field])
        except errors as e:
            logger.warning(
                "%s: invalid '%s' value %r, using default %r: %s",
                context, field, source_dict[field], default, e,
            )
            return default
    else:
        logger.warning("%s: missing '%s', using default %r", context, field, default)
        return default


@dataclass(frozen=True, slots=True)
class RectMarkup(MarkupBase):
    kind: ClassVar[Literal[MarkupKind.RECT]] = MarkupKind.RECT
    stroke_color: Color
    stroke_width: float
    fill_color: Color

    @classmethod
    def from_dict(cls, markup_dict: RectMarkupDict) -> RectMarkup:
        id, page_index, rect = super()._fields_from_dict(markup_dict)
        return cls(
            id=id, page_index=page_index, rect=rect,
            stroke_color=_parse_field(markup_dict, "stroke_color", Color.from_list, _BLACK,
                                      context="RectMarkup.from_dict: RGBA border color"),
            stroke_width=_parse_field(markup_dict, "stroke_width", float, 1.0, (ValueError, TypeError),
                                      context="RectMarkup.from_dict: border width in points"),
            fill_color=_parse_field(markup_dict, "fill_color", Color.from_list, _TRANSPARENT,
                                    context="RectMarkup.from_dict: RGBA fill color"),
        )

    def to_dict(self) -> RectMarkupDict:
        result = super()._fields_to_dict(self.kind)
        result["stroke_color"] = self.stroke_color.to_list()
        result["stroke_width"] = self.stroke_width
        result["fill_color"] = self.fill_color.to_list()
        return result


@dataclass(frozen=True, slots=True)
class TextBoxMarkup(MarkupBase):
    kind: ClassVar[Literal[MarkupKind.TEXT]] = MarkupKind.TEXT
    text: str
    font_size: float
    text_color: Color
    padding: float

    @classmethod
    def from_dict(cls, markup_dict: TextMarkupDict) -> TextBoxMarkup:
        id, page_index, rect = super()._fields_from_dict(markup_dict)
        return cls(
            id=id, page_index=page_index, rect=rect,
            text=_parse_field(markup_dict, "text", str, "",
                              context="TextBoxMarkup.from_dict: text content of the box"),
            font_size=_parse_field(markup_dict, "font_size", float, 12.0, (ValueError, TypeError),
                                   context="TextBoxMarkup.from_dict: font size in points"),
            text_color=_parse_field(markup_dict, "text_color", Color.from_list, _BLACK,
                                    context="TextBoxMarkup.from_dict: RGBA text color"),
            padding=_parse_field(markup_dict, "padding", float, 4.0, (ValueError, TypeError),
                                 context="TextBoxMarkup.from_dict: inner padding in points"),
        )

    def to_dict(self) -> TextMarkupDict:
        result = super()._fields_to_dict(self.kind)
        result["text"] = str(self.text)
        result["font_size"] = float(self.font_size)
        result["text_color"] = self.text_color.to_list()
        result["padding"] = float(self.padding)
        return result


@dataclass(frozen=True, slots=True)
class StampMarkup(MarkupBase):
    kind: ClassVar[Literal[MarkupKind.STAMP]] = MarkupKind.STAMP
    stamp_asset_id: str
    opacity: float

    @classmethod
    def from_dict(cls, markup_dict: StampMarkupDict) -> StampMarkup:
        id, page_index, rect = super()._fields_from_dict(markup_dict)
        return cls(
            id=id, page_index=page_index, rect=rect,
            stamp_asset_id=_parse_field(markup_dict, "stamp_asset_id", str, "",
                                        context="StampMarkup.from_dict: ID referencing the stamp image asset"),
            opacity=_parse_field(markup_dict, "opacity", float, 1.0, (ValueError, TypeError),
                                 context="StampMarkup.from_dict: opacity in range 0.0-1.0"),
        )

    def to_dict(self) -> StampMarkupDict:
        result = super()._fields_to_dict(self.kind)
        result["stamp_asset_id"] = str(self.stamp_asset_id)
        result["opacity"] = float(self.opacity)
        return result

type Markup = RectMarkup | StampMarkup | TextBoxMarkup
