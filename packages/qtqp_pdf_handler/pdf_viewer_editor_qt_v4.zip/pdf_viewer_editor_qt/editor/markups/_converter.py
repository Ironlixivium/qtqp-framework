from typing import assert_never, cast

from ._models import Markup, RectMarkup, StampMarkup, TextBoxMarkup
from ._typing import MarkupDict, RectMarkupDict, StampMarkupDict, TextMarkupDict


def misc_markup_from_dict(markup_dict: MarkupDict) -> Markup:
    kind = markup_dict["kind"]
    match kind:
        case "rect":
            return RectMarkup.from_dict(cast(RectMarkupDict, markup_dict))
        case "stamp":
            return StampMarkup.from_dict(cast(StampMarkupDict, markup_dict))
        case "text":
            return TextBoxMarkup.from_dict(cast(TextMarkupDict, markup_dict))
        case _:
            assert_never()