"""In-memory annotation store with change notifications."""

from collections.abc import Callable, Iterable
from typing import Literal, TypedDict

from ._models import Markup


class StoreEvent(TypedDict):
    type: Literal["reset", "added", "updated", "removed"]
    ids: list[str]


class MarkupStore:
    def __init__(self) -> None:
        self._doc_uid: str | None = None
        self._items: dict[str, Markup] = {}
        self._listeners: list[Callable[[StoreEvent], None]] = []

    @property
    def doc_uid(self) -> str | None:
        return self._doc_uid

    def add_listener(self, fn: Callable[[StoreEvent], None]) -> None:
        self._listeners.append(fn)

    def _emit(self, event: StoreEvent) -> None:
        for fn in list(self._listeners):
            fn(event)

    def set_document(self, doc_uid: str | None) -> None:
        if doc_uid == self._doc_uid:
            return
        self._doc_uid = doc_uid
        self._items.clear()
        self._emit({"type": "reset", "ids": []})

    def reset(self, markups: Iterable[Markup]) -> None:
        self._items = {markup.id: markup for markup in markups}
        self._emit({"type": "reset", "ids": list(self._items.keys())})

    def add(self, markup: Markup) -> None:
        self._items[markup.id] = markup
        self._emit({"type": "added", "ids": [markup.id]})

    def update(self, markup: Markup) -> None:
        self._items[markup.id] = markup
        self._emit({"type": "updated", "ids": [markup.id]})

    def remove(self, markup_id: str) -> None:
        if markup_id in self._items:
            self._items.pop(markup_id, None)
            self._emit({"type": "removed", "ids": [markup_id]})

    def get(self, markup_id: str) -> Markup | None:
        return self._items.get(markup_id)

    def all(self) -> list[Markup]:
        return list(self._items.values())

    def for_page(self, page_index: int) -> list[Markup]:
        return [markup for markup in self._items.values() if markup.page_index == page_index]
