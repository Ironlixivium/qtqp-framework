"""PDF viewer subsystem package."""

from ._widget import PdfViewWidget

__all__ = [
    "PdfViewWidget",
]
