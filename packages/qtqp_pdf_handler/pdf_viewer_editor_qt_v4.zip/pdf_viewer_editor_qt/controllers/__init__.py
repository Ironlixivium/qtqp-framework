"""UI controller layer for coordinating viewer and editor features."""

from .document_session_controller import DocumentSessionController

__all__ = [
    "DocumentSessionController",
]
