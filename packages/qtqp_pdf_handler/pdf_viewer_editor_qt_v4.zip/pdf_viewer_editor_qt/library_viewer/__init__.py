"""Library viewer widgets and models."""

