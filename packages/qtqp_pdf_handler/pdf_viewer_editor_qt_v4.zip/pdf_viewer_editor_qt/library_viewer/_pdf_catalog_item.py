"""Model for a PDF catalog entry."""

from dataclasses import dataclass


@dataclass(frozen=True)
class PdfCatalogItem:
    display_name: str
    source: str
    category: str | None = None
