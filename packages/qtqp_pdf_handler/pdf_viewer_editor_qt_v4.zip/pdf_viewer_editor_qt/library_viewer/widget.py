"""Qt widget for browsing PDFs stored on disk.

Responsibilities:
    - Display a searchable list of PDFs discovered under a templates root.
    - Emit selection signals when a user activates an entry.

Non-responsibilities:
    - Loading PDF bytes (delegated to your existing loader + factory)
    - Rendering PDFs (delegated to your render provider/viewer)

Signals:
    resource_selected(object): Emits a PdfCatalogItem
    document_selected(object): Emits a DocumentPayload (only when a factory is set)
"""

import logging

from PySide6.QtCore import QModelIndex, QSortFilterProxyModel, Qt, Signal
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListView,
    QVBoxLayout,
    QWidget,
)

from ._pdf_catalog_item import PdfCatalogItem
from ..services.document_factory import DocumentFactory, DocumentPayload
from ..services.template_catalog import discover_templates
from .list_model import PdfResourceListModel

logger = logging.getLogger(__name__)


class PdfResourceBrowserWidget(QWidget):
    """Widget that lists PDFs found on disk and emits selections."""

    # PySide6 signals are dynamically typed at runtime, so we keep the signal
    # signature as 'object' and document the emitted type.
    resource_selected: Signal = Signal(object)  # emits PdfCatalogItem
    document_selected: Signal = Signal(object)  # emits DocumentPayload

    def __init__(
        self,
        *,
        factory: DocumentFactory | None = None,
        parent: QWidget | None = None,
        auto_refresh: bool = True,
    ) -> None:
        """Create the browser widget.

        Args:
            factory:
                Optional document factory. If provided, the widget will emit
                both PdfCatalogItem and DocumentPayload on activation.
            parent:
                Qt parent widget.
            auto_refresh:
                If True, discover items immediately during initialization.
        """

        super().__init__(parent)

        self._factory: DocumentFactory | None = factory

        self._model: PdfResourceListModel = PdfResourceListModel(parent=self)
        self._proxy_model: QSortFilterProxyModel = QSortFilterProxyModel(self)
        self._proxy_model.setSourceModel(self._model)
        self._proxy_model.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._proxy_model.setFilterKeyColumn(0)

        # UI fields (assigned in _build_ui)
        self.search_box: QLineEdit
        self.list_view: QListView

        self._build_ui()

        if auto_refresh:
            self.refresh()

    def set_factory(self, factory: DocumentFactory | None) -> None:
        """Set or clear the document factory used to build payloads."""

        self._factory = factory

    def refresh(self) -> None:
        """Re-scan the configured resource root and update the list."""

        items: list[PdfCatalogItem] = discover_templates(recursive=True)
        self._model.set_items(items)

    def _build_ui(self) -> None:
        """Construct child widgets and layouts."""

        root_layout: QVBoxLayout = QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(6)

        header_layout: QHBoxLayout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(6)

        header_label: QLabel = QLabel("PDFs:", self)
        header_layout.addWidget(header_label)

        self.search_box = QLineEdit(self)
        self.search_box.setPlaceholderText("Search...")
        self.search_box.textChanged.connect(self._proxy_model.setFilterFixedString)
        header_layout.addWidget(self.search_box, 1)

        root_layout.addLayout(header_layout)

        self.list_view = QListView(self)
        self.list_view.setModel(self._proxy_model)
        self.list_view.setUniformItemSizes(True)

        # Both signals provide QModelIndex.
        self.list_view.activated.connect(self._on_activated)

        root_layout.addWidget(self.list_view, 1)

    def _on_activated(self, proxy_index: QModelIndex) -> None:
        """Handle user activation (enter/double-click) of a list entry."""

        if not proxy_index.isValid():
            return

        source_index: QModelIndex = self._proxy_model.mapToSource(proxy_index)
        item: PdfCatalogItem | None = self._model.item_from_index(source_index)
        if item is None:
            return

        self.resource_selected.emit(item)

        factory: DocumentFactory | None = self._factory
        if factory is None:
            return

        try:
            payload: DocumentPayload = factory.make(item)
            self.document_selected.emit(payload)
        except Exception:
            logger.exception(
                "Failed to build DocumentPayload for template activation (name=%s, path=%s)",
                item.display_name,
                item.source,
            )
            return
